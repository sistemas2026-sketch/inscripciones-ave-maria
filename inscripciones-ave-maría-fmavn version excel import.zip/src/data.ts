import { Student, Settings } from './types';

export const DEFAULT_SETTINGS: Settings = {
  schoolName: "Ave María - Fundación Manos Abiertas Virgen de la Natividad",
  currentYear: "2026",
  monthlyTuition: 450, // in Bs / local currency
  matriculaAmount: 380, // registration fee
  adminPasscode: "admin123",
  bankInfo: {
    bankName: "Banco Nacional de Bolivia (BNB)",
    accountNumber: "1000293847",
    accountType: "Cuenta Corriente",
    accountHolder: "Fundación Manos Abiertas - Ave María",
    nitOrCI: "1028345025"
  }
};

export const INITIAL_STUDENTS: Student[] = [
  {
    ci: "7777777",
    fullName: "Kamila Vargas Blanco",
    grade: "2do de Secundaria",
    gender: "F",
    birthDate: "2012-05-14",
    hasDebts: false,
    guardianName: "María Mercedes Blanco",
    guardianCI: "4820194",
    guardianPhone: "70582910",
    guardianEmail: "maria.blanco@gmail.com",
    status: "pendiente",
    type: "antiguo"
  },
  {
    ci: "1234567",
    fullName: "Mateo Ortiz Quispe",
    grade: "5to de Primaria",
    gender: "M",
    birthDate: "2015-08-22",
    hasDebts: true,
    pendingMonths: ["Pensiones Marzo 2026", "Pensiones Abril 2026"],
    totalDebtAmount: 900,
    guardianName: "Jorge Ortiz Huanca",
    guardianCI: "3920184",
    guardianPhone: "68042910",
    guardianEmail: "jorge.ortiz@outlook.com",
    status: "pendiente",
    type: "antiguo"
  },
  {
    ci: "8888888",
    fullName: "Sebastian Choque Gomez",
    grade: "6to de Primaria",
    gender: "M",
    birthDate: "2014-11-03",
    hasDebts: false,
    guardianName: "René Choque Calle",
    guardianCI: "5938104",
    guardianPhone: "71283940",
    guardianEmail: "rene.choque@hotmail.com",
    status: "pendiente",
    type: "antiguo"
  },
  {
    ci: "9999999",
    fullName: "Valentina Torrez Rojas",
    grade: "1ro de Primaria",
    gender: "F",
    birthDate: "2019-02-18",
    hasDebts: true,
    pendingMonths: ["Pensión Noviembre 2025", "Pensión Diciembre 2025"],
    totalDebtAmount: 1100, // old debt
    guardianName: "Laura Rojas Alarcón",
    guardianCI: "6029482",
    guardianPhone: "72569201",
    guardianEmail: "laurita.rojas@gmail.com",
    status: "pendiente",
    type: "antiguo"
  },
  {
    ci: "1010101",
    fullName: "Zamir Flores Mamani",
    grade: "Kinder de Inicial",
    gender: "M",
    birthDate: "2021-04-10",
    hasDebts: false,
    guardianName: "Freddy Flores Tintaya",
    guardianCI: "4920485",
    guardianPhone: "70658493",
    guardianEmail: "freddy_flores_t@gmail.com",
    status: "pendiente",
    type: "antiguo"
  },
  {
    ci: "4444444",
    fullName: "Lucía Fernández Cáceres",
    grade: "3ro de Secundaria",
    gender: "F",
    birthDate: "2011-01-30",
    hasDebts: false,
    guardianName: "Carlos Fernández Siles",
    guardianCI: "3849102",
    guardianPhone: "77748192",
    guardianEmail: "cfernandez@colegioavemaria.org",
    status: "inscrito",
    type: "antiguo",
    receiptFileName: "comprobante_banco.pdf",
    receiptFileUrl: "data:application/pdf;base64,JVBERi0xLjQKJ..." ,
    receiptUploadedAt: "2026-05-24T18:30:00Z",
    signedAt: "2026-05-24T18:35:00Z",
    signedByName: "Carlos Fernández Siles",
    paymentNotes: "Transferencia bancaria directa - BNB"
  }
];

export const AVAILABLE_GRADES = [
  "Inicial - Pre-Kinder",
  "Inicial - Kinder",
  "1ro de Primaria",
  "2do de Primaria",
  "3ro de Primaria",
  "4to de Primaria",
  "5to de Primaria",
  "6to de Primaria",
  "1ro de Secundaria",
  "2do de Secundaria",
  "3ro de Secundaria",
  "4to de Secundaria",
  "5to de Secundaria",
  "6to de Secundaria"
];

export function getStoredStudents(): Student[] {
  const data = localStorage.getItem('ave_maria_students');
  if (!data) {
    localStorage.setItem('ave_maria_students', JSON.stringify(INITIAL_STUDENTS));
    return INITIAL_STUDENTS;
  }
  return JSON.parse(data);
}

export function saveStoredStudents(students: Student[]): void {
  localStorage.setItem('ave_maria_students', JSON.stringify(students));
}

export function getStoredSettings(): Settings {
  const data = localStorage.getItem('ave_maria_settings');
  if (!data) {
    localStorage.setItem('ave_maria_settings', JSON.stringify(DEFAULT_SETTINGS));
    return DEFAULT_SETTINGS;
  }
  return JSON.parse(data);
}

export function saveStoredSettings(settings: Settings): void {
  localStorage.setItem('ave_maria_settings', JSON.stringify(settings));
}
