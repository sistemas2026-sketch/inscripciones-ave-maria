export interface Student {
  ci: string;
  fullName: string;
  grade: string;
  gender: 'M' | 'F';
  birthDate: string;
  hasDebts: boolean;
  pendingMonths?: string[];
  totalDebtAmount?: number;
  guardianName: string;
  guardianCI: string;
  guardianPhone: string;
  guardianEmail: string;
  status: 'pendiente' | 'pre-inscrito' | 'inscrito';
  type: 'antiguo' | 'nuevo';
  receiptFileName?: string | null;
  receiptFileUrl?: string | null;
  receiptUploadedAt?: string | null;
  signedAt?: string | null;
  signedByName?: string | null;
  paymentNotes?: string | null;
  createdAt?: string;
  newStudentData?: {
    previousSchool?: string;
    address?: string;
    bloodType?: string;
    emergencyContactName?: string;
    emergencyContactPhone?: string;
  };
}

export interface Settings {
  schoolName: string;
  currentYear: string;
  monthlyTuition: number;
  matriculaAmount: number;
  adminPasscode?: string;
  bankInfo: {
    bankName: string;
    accountNumber: string;
    accountType: string;
    accountHolder: string;
    nitOrCI: string;
  };
}
