import React, { useState } from 'react';
import { Student } from '../types';
import { LogIn, Key, HelpCircle, School, AlertCircle } from 'lucide-react';
import SchoolLogo from './SchoolLogo';

interface StudentLoginProps {
  students: Student[];
  onLoginSuccess: (student: Student) => void;
  onToggleAdmin: () => void;
}

export default function StudentLogin({
  students,
  onLoginSuccess,
  onToggleAdmin
}: StudentLoginProps) {
  const [ciInput, setCiInput] = useState('');
  const [errorHeader, setErrorHeader] = useState('');
  const [errorBody, setErrorBody] = useState<string[] | null>(null);
  const [blockedStudent, setBlockedStudent] = useState<Student | null>(null);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorHeader('');
    setErrorBody(null);
    setBlockedStudent(null);

    const trimmedCI = ciInput.trim();
    if (!trimmedCI) {
      setErrorHeader('Por favor, ingrese el carnet de identidad del estudiante.');
      return;
    }

    const student = students.find(s => s.ci === trimmedCI);

    if (!student) {
      setErrorHeader('Estudiante no encontrado en la base de datos de Alumnos.');
      setErrorBody([
        'Verifique el número de carnet ingresado.',
        'Si el error persiste, comuníquese con secretaría de la Unidad Educativa.'
      ]);
      return;
    }

    // Debt check filter!
    if (student.hasDebts) {
      setBlockedStudent(student);
      setErrorHeader(`FILTRO DE CONTROL DE PAGOS: Ratificación bloqueada para ${student.fullName}`);
      setErrorBody([
        `El estudiante registra saldo pendiente con la institución educativa.`,
        `Detalle: ${student.pendingMonths?.join(', ') || 'Pensiones pendientes acumuladas'}.`,
        `Monto acumulado adeudado: ${student.totalDebtAmount || 900} Bs.`,
        'Para proceder con la ratificación, primero debe regularizar sus cuentas en la caja administrativa o solicitar un plan de pagos.'
      ]);
      return;
    }

    // Success login!
    onLoginSuccess(student);
  };

  return (
    <div className="max-w-md w-full mx-auto" id="student-login-card">
      <div className="bg-white border border-slate-100 rounded-2xl shadow-xl overflow-hidden">
        {/* Header decoration */}
        <div className="bg-gradient-to-br from-blue-800 via-blue-900 to-indigo-950 px-6 py-8 text-white text-center relative flex flex-col items-center">
          <div className="absolute top-3 right-3 bg-white/10 text-white/95 text-[9px] uppercase tracking-widest px-2 py-0.5 rounded-full font-mono">
            Inscripción 2027
          </div>
          <div className="mb-3 shrink-0">
            <SchoolLogo className="w-28 h-16" variant="dark" />
          </div>
          <h2 className="text-sm font-black font-sans tracking-wide leading-none text-center text-white uppercase">
            U.E. Ave María
          </h2>
          <p className="text-[11px] font-bold text-blue-200 uppercase mt-1 leading-none tracking-wider">
            Fundación Manos Abiertas
          </p>
          <p className="text-[10.5px] font-black text-amber-300 uppercase mt-1 leading-none tracking-widest">
            Virgen de la Natividad
          </p>
          <p className="text-[10px] text-slate-300 font-mono italic mt-3 block border-t border-white/10 pt-2 w-full max-w-[200px]">
            Portal de Trámites Digitales
          </p>
        </div>

        {/* Form Body */}
        <div className="p-6">
          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <label htmlFor="ci-student" className="block text-xs font-semibold text-slate-600 uppercase tracking-wide mb-1.5 flex justify-between">
                <span>Carnet de Estudiante (C.I.)</span>
                <span className="text-blue-600 lowercase font-normal italic text-[11px]">Ejemplo: 7777777</span>
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Key className="h-4 w-4 text-slate-400" />
                </div>
                <input
                  id="ci-student"
                  type="text"
                  value={ciInput}
                  onChange={(e) => setCiInput(e.target.value)}
                  placeholder="Ingrese el C.I. del estudiante"
                  className="w-full pl-9 pr-3 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-slate-800 font-medium placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-600 focus:bg-white focus:border-transparent transition-all text-sm"
                />
              </div>
            </div>

            {/* Error Message rendering (Debt or not found) */}
            {errorHeader && (
              <div className="p-4 bg-red-50 border border-red-200 rounded-xl text-xs text-red-800 space-y-1" id="login-error-alert">
                <div className="flex items-start space-x-2 font-bold text-red-950">
                  <AlertCircle className="w-4 h-4 text-red-600 shrink-0 mt-0.5" />
                  <span>{errorHeader}</span>
                </div>
                {errorBody && (
                  <ul className="list-disc pl-5 mt-2 space-y-1 text-[11px] text-red-700">
                    {errorBody.map((line, idx) => (
                      <li key={idx} className="leading-snug">{line}</li>
                    ))}
                  </ul>
                )}
                {blockedStudent && (
                  <div className="mt-3 pt-3 border-t border-red-100 flex justify-between items-center bg-white p-2 rounded-lg border">
                    <span className="text-[10px] text-slate-500 font-mono">Tutor legal: {blockedStudent.guardianName}</span>
                    <a
                      href="https://wa.me/59170582910"
                      target="_blank"
                      rel="noreferrer"
                      className="bg-red-600 text-white rounded px-2 py-1 text-[10px] font-semibold hover:bg-red-700 transition"
                    >
                      Contactar Caja Admin
                    </a>
                  </div>
                )}
              </div>
            )}

            <button
              type="submit"
              className="w-full bg-blue-700 hover:bg-blue-800 text-white font-semibold py-2.5 rounded-xl transition-colors flex items-center justify-center space-x-2 text-sm shadow-md active:scale-[0.98]"
            >
              <LogIn className="w-4.5 h-4.5" />
              <span>Ratificar Inscripción   </span>
            </button>
          </form>
        </div>

        {/* Footer info/Admin toggle */}
        <div className="bg-slate-50 border-t border-slate-100 px-6 py-4 flex items-center justify-between text-xs text-slate-500">
          <span className="flex items-center space-x-1">
            <HelpCircle className="w-3.5 h-3.5 text-slate-400" />
            <span>¿Problemas técnicos?</span>
          </span>
          <button
            onClick={onToggleAdmin}
            className="font-medium text-blue-600 hover:text-blue-800 hover:underline cursor-pointer py-1 px-2 hover:bg-blue-50 rounded"
          >
            Acceder como Administrador
          </button>
        </div>
      </div>
    </div>
  );
}
