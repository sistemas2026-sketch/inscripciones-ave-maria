import React, { useState } from 'react';
import { Student, Settings } from '../types';
import { 
  Users, UserCheck, UserPlus, DollarSign, AlertCircle, Search, Filter, 
  RotateCcw, ShieldAlert, Check, Eye, Trash2, Landmark, Settings as SettingsIcon,
  X, CheckCircle, FileText, Ban, Sparkles, PlusCircle, FileSpreadsheet
} from 'lucide-react';
import { AVAILABLE_GRADES } from '../data';
import ExcelImporter from './ExcelImporter';

interface AdminPanelProps {
  students: Student[];
  settings: Settings;
  onUpdateStudents: (updatedStudents: Student[]) => void;
  onUpdateSettings: (updatedSettings: Settings) => void;
  onClose: () => void;
}

export default function AdminPanel({
  students,
  settings,
  onUpdateStudents,
  onUpdateSettings,
  onClose
}: AdminPanelProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [typeFilter, setTypeFilter] = useState<'todos' | 'antiguo' | 'nuevo'>('todos');
  const [statusFilter, setStatusFilter] = useState<'todos' | 'pendiente' | 'pre-inscrito' | 'inscrito'>('todos');
  const [activeTab, setActiveTab] = useState<'alumnos' | 'configuracion'>('alumnos');

  // Selected student for detail view modal
  const [selectedStudent, setSelectedStudent] = useState<Student | null>(null);

  // Quick addition of a student
  const [showAddModal, setShowAddModal] = useState(false);
  const [showExcelModal, setShowExcelModal] = useState(false);
  const [newAntiguo, setNewAntiguo] = useState({
    ci: '',
    fullName: '',
    grade: AVAILABLE_GRADES[0],
    gender: 'M' as 'M' | 'F',
    hasDebts: false,
    guardianName: '',
    guardianCI: '',
    guardianPhone: '',
    guardianEmail: ''
  });

  // Settings editing state
  const [editedSettings, setEditedSettings] = useState<Settings>({ ...settings });
  const [settingsSuccessMsg, setSettingsSuccessMsg] = useState('');

  // Statistics
  const totalStudentsCount = students.length;
  const registeredCount = students.filter(s => s.status === 'inscrito').length;
  const preRegisteredNewCount = students.filter(s => s.status === 'pre-inscrito').length;
  const pendingCount = students.filter(s => s.status === 'pendiente').length;
  
  const antiguosInscritos = students.filter(s => s.type === 'antiguo' && s.status === 'inscrito').length;
  const nuevosInscritos = students.filter(s => s.type === 'nuevo').length;
  
  // Total money collected: matricula for all enrolled (or pre-enrolled) students
  const activeSubmissions = students.filter(s => s.status === 'inscrito' || s.status === 'pre-inscrito');
  const totalCollectedMoney = activeSubmissions.length * settings.matriculaAmount;
  
  const debtorsCount = students.filter(s => s.hasDebts && s.type === 'antiguo').length;

  // Filter students based on state
  const filteredStudents = students.filter(s => {
    const matchesSearch = s.fullName.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          s.ci.includes(searchTerm);
    const matchesType = typeFilter === 'todos' ? true : s.type === typeFilter;
    const matchesStatus = statusFilter === 'todos' ? true : s.status === statusFilter;
    return matchesSearch && matchesType && matchesStatus;
  });

  // Toggle debt status of returning students
  const handleToggleDebts = (ci: string) => {
    const updated = students.map(s => {
      if (s.ci === ci) {
        const nextDebt = !s.hasDebts;
        return {
          ...s,
          hasDebts: nextDebt,
          // Set or remove sample debt reasons
          pendingMonths: nextDebt ? ["Marzo 2026", "Abril 2026"] : undefined,
          totalDebtAmount: nextDebt ? 900 : undefined
        };
      }
      return s;
    });
    onUpdateStudents(updated);
    
    // Update selected student detail view state in place
    if (selectedStudent && selectedStudent.ci === ci) {
      setSelectedStudent(updated.find(s => s.ci === ci) || null);
    }
  };

  // Delete/Reset student records
  const handleDeleteStudent = (ci: string) => {
    if (confirm('¿Está seguro de eliminar este registro del sistema?')) {
      const updated = students.filter(s => s.ci !== ci);
      onUpdateStudents(updated);
      setSelectedStudent(null);
    }
  };

  // Change student status (approve payment receipts or complete)
  const handleSetStatus = (ci: string, nextStatus: 'pendiente' | 'pre-inscrito' | 'inscrito') => {
    const updated = students.map(s => {
      if (s.ci === ci) {
        return {
          ...s,
          status: nextStatus
        };
      }
      return s;
    });
    onUpdateStudents(updated);
    
    if (selectedStudent && selectedStudent.ci === ci) {
      setSelectedStudent(updated.find(s => s.ci === ci) || null);
    }
  };

  // Add dummy student antigo
  const handleAddAntiguo = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newAntiguo.ci.trim() || !newAntiguo.fullName.trim() || !newAntiguo.guardianName.trim()) {
      alert('Por favor complete los campos requeridos (*)');
      return;
    }

    if (students.some(s => s.ci === newAntiguo.ci)) {
      alert('Ya existe un estudiante registrado con este Carnet de Identidad (C.I.).');
      return;
    }

    const created: Student = {
      ci: newAntiguo.ci.trim(),
      fullName: newAntiguo.fullName.trim(),
      grade: newAntiguo.grade,
      gender: newAntiguo.gender,
      birthDate: '2014-04-10',
      hasDebts: newAntiguo.hasDebts,
      pendingMonths: newAntiguo.hasDebts ? ["Pensiones Marzo", "Pensiones Abril"] : undefined,
      totalDebtAmount: newAntiguo.hasDebts ? 900 : undefined,
      guardianName: newAntiguo.guardianName.trim(),
      guardianCI: newAntiguo.guardianCI.trim() || '4928104',
      guardianPhone: newAntiguo.guardianPhone.trim() || '70549201',
      guardianEmail: newAntiguo.guardianEmail.trim() || 'contact@example.com',
      status: 'pendiente',
      type: 'antiguo'
    };

    onUpdateStudents([...students, created]);
    setShowAddModal(false);
    
    // reset form fields
    setNewAntiguo({
      ci: '',
      fullName: '',
      grade: AVAILABLE_GRADES[0],
      gender: 'M',
      hasDebts: false,
      guardianName: '',
      guardianCI: '',
      guardianPhone: '',
      guardianEmail: ''
    });
  };

  const handleExcelImportComplete = (importedList: Student[], mode: 'append' | 'replace') => {
    if (mode === 'replace') {
      onUpdateStudents(importedList);
    } else {
      const currentMap = new Map(students.map(s => [s.ci, s]));
      importedList.forEach(imported => {
        if (currentMap.has(imported.ci)) {
          const existing = currentMap.get(imported.ci)!;
          // Merge: update fields but preserve historical status, attachments, logs etc.
          currentMap.set(imported.ci, {
            ...existing,
            fullName: imported.fullName,
            grade: imported.grade,
            gender: imported.gender,
            hasDebts: imported.hasDebts,
            pendingMonths: imported.pendingMonths || existing.pendingMonths,
            totalDebtAmount: imported.totalDebtAmount !== undefined ? imported.totalDebtAmount : existing.totalDebtAmount,
            guardianName: imported.guardianName !== 'Tutor por Registrar' ? imported.guardianName : existing.guardianName,
            guardianCI: imported.guardianCI !== '4900000' ? imported.guardianCI : existing.guardianCI,
            guardianPhone: imported.guardianPhone !== '70000000' ? imported.guardianPhone : existing.guardianPhone,
            guardianEmail: imported.guardianEmail !== 'tutor@example.com' ? imported.guardianEmail : existing.guardianEmail
          });
        } else {
          currentMap.set(imported.ci, imported);
        }
      });
      onUpdateStudents(Array.from(currentMap.values()));
    }
  };

  // Settings modification submit
  const handleSaveSettings = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateSettings(editedSettings);
    setSettingsSuccessMsg('Configuración financiera e institucional guardada con éxito.');
    setTimeout(() => setSettingsSuccessMsg(''), 4000);
  };

  // Dev Reset: restore defaults
  const handleDevReset = () => {
    if (confirm('¿Desea restaurar la base de datos a los valores de demostración iniciales? Esto borrará nuevos alumnos registrados.')) {
      localStorage.removeItem('ave_maria_students');
      localStorage.removeItem('ave_maria_settings');
      window.location.reload();
    }
  };

  return (
    <div className="bg-slate-100 min-h-screen pb-12" id="admin-dashboard-container">
      {/* Top Navbar */}
      <div className="bg-slate-900 text-white py-4 px-6 md:px-12 flex flex-col md:flex-row justify-between items-center border-b border-slate-800 shadow-md">
        <div className="flex items-center space-x-3 mb-3 md:mb-0">
          <Landmark className="w-7 h-7 text-amber-400" />
          <div>
            <h1 className="font-bold text-lg leading-tight uppercase font-mono tracking-wider text-amber-300">ADMINISTRADOR - GESTIÓN ESCOLAR</h1>
            <p className="text-xs text-slate-400">Panel de Control de Matrículas e Inscripciones {settings.schoolName}</p>
          </div>
        </div>

        <div className="flex items-center space-x-3">
          <button
            onClick={handleDevReset}
            type="button"
            className="text-xs cursor-pointer bg-slate-800 hover:bg-slate-700 hover:text-white text-slate-300 border border-slate-700 px-3 py-2 rounded-lg flex items-center space-x-1.5 transition-all font-mono"
            title="Borrar localStorage y restaurar simulación inicial"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Restaurar BD Inicial</span>
          </button>
          
          <button
            onClick={onClose}
            className="bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold px-4 py-2 rounded-lg shadow transition-colors cursor-pointer"
          >
            Cerrar Panel Administrativo
          </button>
        </div>
      </div>

      {/* Stats Board Section */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-6">
        <div className="grid grid-cols-2 md:grid-cols-6 gap-4" id="stats-dashboard-grid">
          
          {/* Total DB */}
          <div className="bg-white border border-slate-200 p-4 rounded-xl shadow-sm text-left relative overflow-hidden">
            <span className="block text-[10px] font-bold text-slate-400 uppercase">Totales BD</span>
            <span className="text-2xl font-extrabold text-slate-800 block mt-1">{totalStudentsCount}</span>
            <span className="text-[10px] text-slate-500 mt-1 block font-medium">Alumnos cargados</span>
            <div className="absolute right-2 bottom-2 bg-slate-50 p-1.5 rounded-full text-slate-300">
              <Users className="w-5 h-5" />
            </div>
          </div>

          {/* Enrolled OK */}
          <div className="bg-white border border-slate-200 p-4 rounded-xl shadow-sm text-left relative overflow-hidden">
            <span className="block text-[10px] font-bold text-emerald-600 uppercase">Inscritos Completos</span>
            <span className="text-2xl font-extrabold text-emerald-700 block mt-1">{registeredCount}</span>
            <span className="text-[10px] text-emerald-600 mt-1 block font-semibold">{antiguosInscritos} antiguos finalizados</span>
            <div className="absolute right-2 bottom-2 bg-emerald-50 p-1.5 rounded-full text-emerald-200">
              <UserCheck className="w-5 h-5" />
            </div>
          </div>

          {/* Pre-enrolled (Nuevos waiting approval) */}
          <div className="bg-white border border-slate-200 p-4 rounded-xl shadow-sm text-left relative overflow-hidden">
            <span className="block text-[10px] font-bold text-amber-600 uppercase">Pre-inscritos Nuevos</span>
            <span className="text-2xl font-extrabold text-amber-700 block mt-1">{preRegisteredNewCount}</span>
            <span className="text-[10px] text-amber-500 mt-1 block font-medium">Requieren revisar físico</span>
            <div className="absolute right-2 bottom-2 bg-amber-50 p-1.5 rounded-full text-amber-200">
              <UserPlus className="w-5 h-5" />
            </div>
          </div>

          {/* Pending submission */}
          <div className="bg-white border border-slate-200 p-4 rounded-xl shadow-sm text-left relative overflow-hidden">
            <span className="block text-[10px] font-bold text-slate-400 uppercase">Pendientes Trámite</span>
            <span className="text-2xl font-extrabold text-slate-600 block mt-1">{pendingCount}</span>
            <span className="text-[10px] text-slate-400 mt-1 block font-medium">Sin ratificar trámite</span>
            <div className="absolute right-2 bottom-2 bg-slate-50 p-1.5 rounded-full text-slate-400">
              <AlertCircle className="w-5 h-5" />
            </div>
          </div>

          {/* Revenue */}
          <div className="bg-white border border-slate-200 p-4 rounded-xl shadow-sm text-left relative overflow-hidden">
            <span className="block text-[10px] font-bold text-blue-600 uppercase">Recaudado Matrículas</span>
            <span className="text-2xl font-extrabold text-blue-700 block mt-1">{totalCollectedMoney} Bs.</span>
            <span className="text-[10px] text-blue-500 mt-1 block font-bold">Por {activeSubmissions.length} postulados</span>
            <div className="absolute right-2 bottom-2 bg-blue-50 p-1.5 rounded-full text-blue-200">
              <DollarSign className="w-5 h-5" />
            </div>
          </div>

          {/* Active debts filter indicator */}
          <div className="bg-white border border-slate-200 p-4 rounded-xl shadow-sm text-left relative overflow-hidden">
            <span className="block text-[10px] font-bold text-red-500 uppercase">Filtro Mora Activa</span>
            <span className="text-2xl font-extrabold text-red-600 block mt-1">{debtorsCount}</span>
            <span className="text-[10px] text-red-500 mt-1 block font-bold">Bloqueados en Ingreso</span>
            <div className="absolute right-2 bottom-2 bg-red-50 p-1.5 rounded-full text-red-200">
              <ShieldAlert className="w-5 h-5" />
            </div>
          </div>

        </div>
      </div>

      {/* Main Core Container */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-6">
        
        {/* Tab Selection Navigation */}
        <div className="flex border-b border-slate-200 mb-4 bg-white p-1 rounded-lg shadow-sm max-w-sm">
          <button
            onClick={() => setActiveTab('alumnos')}
            className={`flex-1 py-1.5 px-3 text-xs font-bold rounded-md transition-all ${
              activeTab === 'alumnos' 
                ? 'bg-slate-900 text-white shadow-sm' 
                : 'text-slate-600 hover:bg-slate-100 hover:text-slate-800'
            }`}
          >
            Listado y Ratificaciones
          </button>
          <button
            onClick={() => setActiveTab('configuracion')}
            className={`flex-1 py-1.5 px-3 text-xs font-bold rounded-md transition-all ${
              activeTab === 'configuracion' 
                ? 'bg-slate-900 text-white shadow-sm' 
                : 'text-slate-600 hover:bg-slate-100 hover:text-slate-800'
            }`}
          >
            Configurar Costos y Banco
          </button>
        </div>

        {activeTab === 'alumnos' ? (
          <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden" id="admin-students-portal">
            
            {/* Table Filters Action Header */}
            <div className="p-5 border-b border-slate-150 flex flex-col md:flex-row md:items-center md:justify-between gap-4 bg-slate-50/55">
              <div className="flex-1 max-w-md relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Search className="h-4 w-4 text-slate-400" />
                </div>
                <input
                  type="text"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  placeholder="Buscar estudiante por nombre o C.I..."
                  className="w-full pl-9 pr-3 py-2 bg-white border border-slate-300 rounded-lg text-xs font-medium focus:outline-none focus:ring-2 focus:ring-blue-600 transition"
                />
              </div>

              <div className="flex flex-wrap items-center gap-3">
                {/* Type Filter */}
                <div className="flex items-center space-x-1 bg-white border border-slate-300 rounded-lg px-2 py-1">
                  <Filter className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                  <select
                    value={typeFilter}
                    onChange={(e) => setTypeFilter(e.target.value as any)}
                    className="bg-transparent border-none text-[11px] font-semibold text-slate-600 focus:outline-none"
                  >
                    <option value="todos">Tipo: Todos</option>
                    <option value="antiguo">Antiguos (Ratificaciones)</option>
                    <option value="nuevo">Nuevos (Ingreso)</option>
                  </select>
                </div>

                {/* Status Filter */}
                <div className="flex items-center space-x-1 bg-white border border-slate-300 rounded-lg px-2 py-1">
                  <Filter className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                  <select
                    value={statusFilter}
                    onChange={(e) => setStatusFilter(e.target.value as any)}
                    className="bg-transparent border-none text-[11px] font-semibold text-slate-600 focus:outline-none"
                  >
                    <option value="todos">Estado: Todos</option>
                    <option value="pendiente">Pendiente sin iniciar</option>
                    <option value="pre-inscrito">Pre-inscrito (Nuevo)</option>
                    <option value="inscrito">Inscrito / Ratificado</option>
                  </select>
                </div>

                {/* Import from Excel */}
                <button
                  type="button"
                  onClick={() => setShowExcelModal(true)}
                  className="bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs py-1.5 px-3 rounded-lg flex items-center space-x-1 translate active:scale-[0.98] cursor-pointer transition shadow-sm"
                >
                  <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-300" />
                  <span>Importar Excel</span>
                </button>

                {/* Add new student dummy */}
                <button
                  type="button"
                  onClick={() => setShowAddModal(true)}
                  className="bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs py-1.5 px-3 rounded-lg flex items-center space-x-1 cursor-pointer transition shadow-sm"
                >
                  <PlusCircle className="w-3.5 h-3.5" />
                  <span>Añadir Estudiante</span>
                </button>
              </div>
            </div>

            {/* Students Table */}
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="bg-slate-50 border-b border-slate-200 text-[10px] font-bold uppercase tracking-wider text-slate-500">
                    <th className="py-3 px-4">Carnet (CI)</th>
                    <th className="py-3 px-4">Estudiante</th>
                    <th className="py-3 px-4">Grado</th>
                    <th className="py-3 px-4">Tipo</th>
                    <th className="py-3 px-4 text-center">Filtro Pagos (Mora)</th>
                    <th className="py-3 px-4">Trámite Inscripción</th>
                    <th className="py-3 px-4 text-center">Acciones</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-150 text-slate-700">
                  {filteredStudents.length > 0 ? (
                    filteredStudents.map((st) => (
                      <tr key={st.ci} className="hover:bg-slate-50 transition-all font-medium">
                        {/* CI */}
                        <td className="py-3.5 px-4 font-mono font-medium text-slate-500">{st.ci}</td>
                        
                        {/* Name */}
                        <td className="py-3.5 px-4">
                          <span className="font-bold text-slate-800 block uppercase leading-snug">{st.fullName}</span>
                          <span className="text-[10px] text-slate-400 block font-normal leading-tight">Tutor: {st.guardianName}</span>
                        </td>
                        
                        {/* Grade */}
                        <td className="py-3.5 px-4">
                          <span className="px-2 py-0.5 rounded bg-blue-50 text-blue-700 font-semibold text-[11px] block w-fit">
                            {st.grade}
                          </span>
                        </td>

                        {/* Type (antiguo/nuevo) */}
                        <td className="py-3.5 px-4">
                          {st.type === 'antiguo' ? (
                            <span className="text-slate-500 font-bold bg-slate-100 border border-slate-200 rounded px-1.5 py-0.5">Antiguo</span>
                          ) : (
                            <span className="text-amber-800 font-bold bg-amber-50 border border-amber-200 rounded px-1.5 py-0.5">Nuevo</span>
                          )}
                        </td>

                        {/* Debt Status Control */}
                        <td className="py-3.5 px-4 text-center">
                          {st.type === 'antiguo' ? (
                            <button
                              onClick={() => handleToggleDebts(st.ci)}
                              type="button"
                              className={`mx-auto cursor-pointer flex items-center space-x-1 px-3 py-1.5 rounded-full text-[10px] font-bold border transition ${
                                st.hasDebts 
                                  ? 'bg-rose-50 border-rose-200 text-rose-700 hover:bg-rose-100' 
                                  : 'bg-emerald-50 border-emerald-200 text-emerald-700 hover:bg-emerald-100'
                              }`}
                              title="Haga clic para cambiar estado del deudor al instante"
                            >
                              <span className="w-2 h-2 rounded-full" style={{ backgroundColor: st.hasDebts ? '#dc2626' : '#10b981' }} />
                              <span>{st.hasDebts ? 'CON MORA / BLOQUEAR' : 'AL DÍA (Permitido)'}</span>
                            </button>
                          ) : (
                            <span className="text-slate-400 italic font-normal text-[10px]">No Aplica deudas</span>
                          )}
                        </td>

                        {/* Registration Status */}
                        <td className="py-3.5 px-4">
                          {st.status === 'pendiente' && (
                            <span className="px-2 py-0.5 rounded-full text-[10.5px] font-bold bg-slate-100 text-slate-500 border border-slate-200">
                              No Iniciado / Pendiente
                            </span>
                          )}
                          {st.status === 'pre-inscrito' && (
                            <span className="px-2 py-0.5 rounded-full text-[10.5px] font-bold bg-amber-50 text-amber-700 border border-amber-200 animate-pulse">
                              Pre-Inscrito (Verificar)
                            </span>
                          )}
                          {st.status === 'inscrito' && (
                            <span className="px-2 py-0.5 rounded-full text-[10.5px] font-bold bg-emerald-50 text-emerald-700 border border-emerald-200">
                              ✓ Completado / Inscrito
                            </span>
                          )}
                        </td>

                        {/* Actions */}
                        <td className="py-3.5 px-4 text-center">
                          <div className="flex items-center justify-center space-x-2">
                            <button
                              onClick={() => setSelectedStudent(st)}
                              className="p-1 px-2.5 bg-slate-100 text-slate-700 rounded hover:bg-blue-600 hover:text-white transition flex items-center space-x-1 cursor-pointer font-bold"
                              title="Revisar expediente, aceptación de contrato y comprobantes"
                            >
                              <Eye className="w-3.5 h-3.5" />
                              <span>Revisar</span>
                            </button>
                            
                            <button
                              onClick={() => handleDeleteStudent(st.ci)}
                              className="p-1 bg-slate-100 text-slate-400 hover:bg-rose-50 hover:text-red-600 rounded transition cursor-pointer"
                              title="Borrar registro"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))
                  ) : (
                    <tr>
                      <td colSpan={7} className="py-8 text-center text-slate-450 font-medium">
                        No se encontraron estudiantes para los filtros seleccionados.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>

            {/* Total Footer Banner count */}
            <div className="bg-slate-50 border-t border-slate-100 p-4 px-6 text-xs text-slate-500 font-semibold flex justify-between items-center">
              <span>Mostrando {filteredStudents.length} de {students.length} estudiantes</span>
              <span className="text-blue-700">Monto total estimado recaudado: {totalCollectedMoney} Bs.</span>
            </div>

          </div>
        ) : (
          /* CONFIGURATION TAB CONTENT */
          <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6 max-w-2xl" id="admin-settings-box">
            <h3 className="text-base font-bold text-slate-800 flex items-center space-x-2 border-b border-slate-150 pb-3 mb-4">
              <SettingsIcon className="w-5 h-5 text-blue-600" />
              <span>Configuración Global del Colegio y Financiera</span>
            </h3>

            <p className="text-xs text-slate-500 mb-5 leading-relaxed">
              Los cambios guardados aquí se aplicarán automáticamente a los nuevos contratos de servicios educativos, requisitos del comprobante de transferencia y simulador bancario en tiempo real.
            </p>

            {settingsSuccessMsg && (
              <div className="p-4 bg-emerald-50 border border-emerald-100 text-emerald-800 font-semibold rounded-lg text-xs mb-4 flex items-center space-x-2">
                <CheckCircle className="w-4.5 h-4.5 text-emerald-600" />
                <span>{settingsSuccessMsg}</span>
              </div>
            )}

            <form onSubmit={handleSaveSettings} className="space-y-4 text-xs font-semibold">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                
                <div>
                  <label className="block text-slate-600 mb-1.5">Nombre Oficial del Colegio:</label>
                  <input
                    type="text"
                    value={editedSettings.schoolName}
                    onChange={(e) => setEditedSettings({...editedSettings, schoolName: e.target.value})}
                    className="w-full bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 text-sm text-slate-800 font-bold focus:ring-1 focus:ring-blue-600 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-slate-600 mb-1.5">Año Gestión Escolar:</label>
                  <input
                    type="text"
                    value={editedSettings.currentYear}
                    onChange={(e) => setEditedSettings({...editedSettings, currentYear: e.target.value})}
                    className="w-full bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 text-sm text-slate-800 font-bold focus:ring-1 focus:ring-blue-600 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-slate-600 mb-1.5">Costo Mensualidad / Pensión (Bs.):</label>
                  <input
                    type="number"
                    value={editedSettings.monthlyTuition}
                    onChange={(e) => setEditedSettings({...editedSettings, monthlyTuition: Number(e.target.value)})}
                    className="w-full bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 text-sm text-slate-800 font-bold focus:ring-1 focus:ring-blue-600 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-slate-600 mb-1.5">Costo Matrícula / Registro Anual (Bs.):</label>
                  <input
                    type="number"
                    value={editedSettings.matriculaAmount}
                    onChange={(e) => setEditedSettings({...editedSettings, matriculaAmount: Number(e.target.value)})}
                    className="w-full bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 text-sm text-slate-800 font-bold focus:ring-1 focus:ring-blue-600 focus:outline-none"
                  />
                </div>

                <div className="col-span-1 md:col-span-2 pt-3 border-t border-slate-100">
                  <h4 className="text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-3">Información Cuenta Bancaria Colegio</h4>
                </div>

                <div>
                  <label className="block text-slate-600 mb-1.5">Banco de Depósito:</label>
                  <input
                    type="text"
                    value={editedSettings.bankInfo.bankName}
                    onChange={(e) => setEditedSettings({
                      ...editedSettings, 
                      bankInfo: {...editedSettings.bankInfo, bankName: e.target.value}
                    })}
                    className="w-full bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 text-xs text-slate-800 font-bold focus:ring-1 focus:ring-blue-600 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-slate-600 mb-1.5">Número de Cuenta Colegio:</label>
                  <input
                    type="text"
                    value={editedSettings.bankInfo.accountNumber}
                    onChange={(e) => setEditedSettings({
                      ...editedSettings, 
                      bankInfo: {...editedSettings.bankInfo, accountNumber: e.target.value}
                    })}
                    className="w-full bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 text-xs text-slate-800 font-bold font-mono focus:ring-1 focus:ring-blue-600 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-slate-600 mb-1.5">Nombre del Titular de Cuenta:</label>
                  <input
                    type="text"
                    value={editedSettings.bankInfo.accountHolder}
                    onChange={(e) => setEditedSettings({
                      ...editedSettings, 
                      bankInfo: {...editedSettings.bankInfo, accountHolder: e.target.value}
                    })}
                    className="w-full bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 text-xs text-slate-800 font-bold focus:ring-1 focus:ring-blue-600 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-slate-600 mb-1.5">NIT o C.I. Empresa:</label>
                  <input
                    type="text"
                    value={editedSettings.bankInfo.nitOrCI}
                    onChange={(e) => setEditedSettings({
                      ...editedSettings, 
                      bankInfo: {...editedSettings.bankInfo, nitOrCI: e.target.value}
                    })}
                    className="w-full bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 text-xs text-slate-800 font-bold focus:ring-1 focus:ring-blue-600 focus:outline-none"
                  />
                </div>

                <div className="col-span-1 md:col-span-2 pt-3 border-t border-slate-100">
                  <h4 className="text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-2">Seguridad de Acceso</h4>
                </div>

                <div className="col-span-1 md:col-span-2">
                  <label className="block text-slate-600 mb-1.5">Código de Acceso del Administrador:</label>
                  <input
                    type="text"
                    value={editedSettings.adminPasscode || ""}
                    placeholder="admin123"
                    onChange={(e) => setEditedSettings({
                      ...editedSettings, 
                      adminPasscode: e.target.value
                    })}
                    className="w-full bg-slate-50 border border-slate-300 rounded-lg px-3.5 py-2.5 text-xs text-slate-800 font-bold focus:ring-1 focus:ring-blue-600 focus:outline-none max-w-sm font-mono tracking-widest"
                  />
                  <p className="text-[10.5px] text-slate-400 mt-1.5 italic leading-relaxed">
                    Cambie esto para restringir el portal de administración únicamente a su persona. El valor predeterminado es <strong className="font-mono">admin123</strong>. ¡Asegúrese de anotarlo antes de guardarlo!
                  </p>
                </div>

              </div>

              <div className="pt-6 border-t border-slate-100 flex justify-end">
                <button
                  type="submit"
                  className="bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-5 rounded-lg shadow cursor-pointer transition text-xs"
                >
                  Guardar Configuración
                </button>
              </div>
            </form>
          </div>
        )}

      </div>

      {/* DETAIL MODAL - STUDENT INSPECTOR APPLICANT */}
      {selectedStudent && (
        <div className="fixed inset-0 bg-slate-900/60 flex items-center justify-center p-4 z-50 overflow-y-auto" id="student-detail-modal">
          <div className="bg-white rounded-2xl border border-slate-200 shadow-2xl max-w-4xl w-full max-h-[90vh] overflow-hidden flex flex-col">
            
            {/* Modal Header */}
            <div className="bg-slate-900 text-white p-5 flex justify-between items-center border-b border-slate-850 shrink-0">
              <div className="flex items-center space-x-2">
                <Users className="w-5 h-5 text-amber-400" />
                <div>
                  <h3 className="font-bold text-sm tracking-wide uppercase font-mono">EXPEDIENTE DEL ESTUDIANTE CONTROLES</h3>
                  <p className="text-[10px] text-slate-400">Inspección de aceptación de contrato (PDF) y ticket comprobante de depósito en línea</p>
                </div>
              </div>
              <button
                onClick={() => setSelectedStudent(null)}
                className="text-slate-400 hover:text-white hover:bg-slate-800 p-1 rounded-full transition cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Body scrollable */}
            <div className="p-6 overflow-y-auto space-y-6 text-left text-xs text-slate-700 custom-scrollbar">
              
              {/* Profile Overview */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 border-b border-slate-100 pb-5">
                <div>
                  <span className="block text-[10px] text-slate-400 font-bold uppercase">ALUMNO COMPLETO:</span>
                  <span className="font-bold text-sm text-slate-800 uppercase block">{selectedStudent.fullName}</span>
                  <span className="text-slate-500">Carnet: {selectedStudent.ci}</span>
                </div>
                <div>
                  <span className="block text-[10px] text-slate-400 font-bold uppercase">GRADO REGISTRADO:</span>
                  <span className="px-2.5 py-0.5 rounded bg-blue-50 text-blue-800 font-bold text-[11px] inline-block mt-0.5">{selectedStudent.grade}</span>
                </div>
                <div>
                  <span className="block text-[10px] text-slate-400 font-bold uppercase">TIPO / ESTADO:</span>
                  <div className="space-x-1.5 mt-0.5 inline-block">
                    {selectedStudent.type === 'antiguo' ? (
                      <span className="bg-slate-100 border text-slate-800 font-bold px-1.5 py-0.5 rounded">Antiguo</span>
                    ) : (
                      <span className="bg-amber-50 text-amber-800 border border-amber-200 font-bold px-1.5 py-0.5 rounded">Nuevo</span>
                    )}
                    
                    {selectedStudent.status === 'pendiente' && (
                      <span className="bg-slate-100 border text-slate-500 font-bold px-1.5 py-0.5 rounded">No Ratificado</span>
                    )}
                    {selectedStudent.status === 'pre-inscrito' && (
                      <span className="bg-amber-50 border border-amber-200 text-amber-700 font-bold px-1.5 py-0.5 rounded animate-pulse">Pre-Inscrito</span>
                    )}
                    {selectedStudent.status === 'inscrito' && (
                      <span className="bg-emerald-50 border border-emerald-200 text-emerald-800 font-bold px-1.5 py-0.5 rounded">Inscripción Ratificada</span>
                    )}
                  </div>
                </div>
              </div>

              {/* Tutor & Address Section */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="bg-slate-50/50 p-4 border border-slate-200 rounded-xl space-y-2">
                  <span className="font-bold block text-[10.5px] uppercase text-slate-600 tracking-wide border-b border-slate-200/60 pb-1.5">Información Legal de Tutor</span>
                  <p><strong>Apellidos y Nombres:</strong> {selectedStudent.guardianName || 'Sin Registrar'}</p>
                  <p><strong>C.I. Tutor:</strong> {selectedStudent.guardianCI || 'Sin Registrar'}</p>
                  <p><strong>Celular WhatsApp:</strong> {selectedStudent.guardianPhone || 'Sin Registrar'}</p>
                  <p><strong>Email registrado:</strong> {selectedStudent.guardianEmail || 'Sin Registrar'}</p>
                </div>

                <div className="bg-slate-50/50 p-4 border border-slate-200 rounded-xl space-y-2">
                  <span className="font-bold block text-[10.5px] uppercase text-slate-600 tracking-wide border-b border-slate-200/60 pb-1.5">Información Bioquímica / Colegio Anterior</span>
                  {selectedStudent.type === 'nuevo' && selectedStudent.newStudentData ? (
                    <>
                      <p><strong>Unidad anterior:</strong> {selectedStudent.newStudentData.previousSchool || 'No Especificado'}</p>
                      <p><strong>Grupo Sanguíneo:</strong> {selectedStudent.newStudentData.bloodType || 'Sin Registrar'}</p>
                      <p><strong>Contacto Emergencia:</strong> {selectedStudent.newStudentData.emergencyContactName || 'No especificado'}</p>
                    </>
                  ) : (
                    <p className="text-slate-400 italic">Datos extendidos solo aplican para Estudiantes Nuevos de primer ingreso.</p>
                  )}
                  {selectedStudent.type === 'antiguo' && (
                    <div className="pt-1.5 space-y-1.5">
                      <p><strong>Estado Deuda actual:</strong> <span className={selectedStudent.hasDebts ? 'text-red-600 font-bold' : 'text-emerald-700 font-bold'}>{selectedStudent.hasDebts ? 'Con Mora/Inhabilitado' : 'Al Día/Permitido'}</span></p>
                      {selectedStudent.hasDebts && (
                        <p className="text-[11px] bg-red-50 text-red-700 p-2 rounded"><strong>Meses pendientes:</strong> {selectedStudent.pendingMonths?.join(', ')} • ({selectedStudent.totalDebtAmount} Bs.)</p>
                      )}
                    </div>
                  )}
                </div>
              </div>

              {/* Uploaded Payment Receipt and Digital Signature verification */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                
                {/* PDF RECEIPT PREVIEW PANEL */}
                <div className="border border-slate-200 rounded-xl p-4 flex flex-col justify-between bg-slate-50/20">
                  <div>
                    <span className="font-bold block text-[10.5px] uppercase text-slate-600 tracking-wide border-b border-slate-200 pb-2 mb-3">
                      Comprobante de Depósito Cargado
                    </span>
                    {selectedStudent.receiptFileName ? (
                      <div className="space-y-3">
                        <div className="p-3 bg-emerald-50 border border-emerald-100 rounded-lg flex items-center space-x-2 w-full">
                          <FileText className="w-5 h-5 text-emerald-600 shrink-0" />
                          <div className="truncate text-left font-medium">
                            <p className="text-slate-800 text-[11.5px] truncate font-bold">{selectedStudent.receiptFileName}</p>
                            <p className="text-[9.5px] text-emerald-600 mt-0.5">Archivo PDF / Imagen válida de pago registrado</p>
                          </div>
                        </div>

                        {/* Simulated Visual representation of bank voucher to make it visually mind-blowing */}
                        <div className="bg-white p-3 border border-slate-200 rounded-lg text-[10px] space-y-1.5 font-mono shadow-sm">
                          <div className="text-center font-bold text-slate-600 tracking-wide border-b pb-1">TICKET BANCARIO SIMULADO</div>
                          <p><strong>BANCO:</strong> BNB EN LÍNEA</p>
                          <p><strong>BENEFICIARIO:</strong> AVE MARÍA S.R.L.</p>
                          <p><strong>TRAMITE:</strong> MATRICULACIÓN {settings.currentYear}</p>
                          <p><strong>MONTO ABONADO:</strong> {settings.matriculaAmount} Bs.</p>
                          <p><strong>NIVEL ESTUDIANTE:</strong> {selectedStudent.grade}</p>
                          <p><strong>GLOSA PADRE:</strong> {selectedStudent.paymentNotes || 'DEPÓSITO ELECTRÓNICO'}</p>
                        </div>
                      </div>
                    ) : (
                      <div className="flex flex-col items-center justify-center py-6 border border-slate-300 border-dashed rounded-lg bg-slate-50">
                        <Ban className="w-8 h-8 text-slate-300 mb-1" />
                        <span className="text-slate-400">No se ha subido ningún archivo aún</span>
                      </div>
                    )}
                  </div>
                </div>

                {/* CONTRACT ACCEPTANCE PANEL */}
                <div className="border border-slate-200 rounded-xl p-4 flex flex-col justify-between bg-slate-50/20">
                  <div>
                    <span className="font-bold block text-[10.5px] uppercase text-slate-600 tracking-wide border-b border-slate-200 pb-2 mb-3">
                      Aceptación de Contrato (PDF)
                    </span>
                    {selectedStudent.signedAt ? (
                      <div className="space-y-2 text-left text-xs text-slate-700">
                        <div className="p-2 border border-emerald-100 bg-emerald-50/30 rounded text-[11px] font-semibold text-emerald-800">
                          ✓ Contrato Aceptado y Descargado
                        </div>
                        <p><strong>Tutor / Apoderado:</strong> {selectedStudent.signedByName || selectedStudent.guardianName}</p>
                        <p><strong>C.I. del Tutor:</strong> {selectedStudent.guardianCI || "Registrado"}</p>
                        <p><strong>Fecha de Ratificación:</strong> {new Date(selectedStudent.signedAt).toLocaleString()}</p>
                        <p className="text-[10px] text-slate-500 italic mt-2 leading-relaxed">
                          * El tutor legal completó el domicilio y descargó el documento oficial de prestación de servicios para la Gestión {settings.currentYear}.
                        </p>
                      </div>
                    ) : (
                      <div className="flex flex-col items-center justify-center py-6 border border-slate-300 border-dashed rounded-lg bg-slate-50 text-slate-400">
                        <Ban className="w-8 h-8 text-slate-300 mb-1" />
                        <span>Contrato pendiente de descarga</span>
                      </div>
                    )}
                  </div>
                </div>

              </div>

              {/* Status Update / Action Toolbar inside details */}
              <div className="pt-5 border-t border-slate-200 flex flex-wrap gap-3 justify-between items-center shrink-0">
                <div className="flex space-x-2">
                  <button
                    onClick={() => handleDeleteStudent(selectedStudent.ci)}
                    className="bg-red-50 hover:bg-red-100 border border-red-200 text-red-700 px-3 py-2 rounded-lg font-bold flex items-center space-x-1 transition cursor-pointer"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>Eliminar Registro del Sistema</span>
                  </button>
                  
                  {selectedStudent.type === 'antiguo' && (
                    <button
                      onClick={() => handleToggleDebts(selectedStudent.ci)}
                      className={`px-3 py-2 rounded-lg font-bold border transition cursor-pointer ${
                        selectedStudent.hasDebts 
                          ? 'bg-emerald-50 hover:bg-emerald-100 text-emerald-700 border-emerald-200' 
                          : 'bg-rose-50 hover:bg-rose-100 text-rose-700 border-rose-200'
                      }`}
                    >
                      <span>Simular: {selectedStudent.hasDebts ? 'Perdonar deudas (Al día)' : 'Cargar Mora administrativa'}</span>
                    </button>
                  )}
                </div>

                <div className="flex space-x-2">
                  {selectedStudent.status !== 'inscrito' && (
                    <button
                      onClick={() => handleSetStatus(selectedStudent.ci, 'inscrito')}
                      className="bg-emerald-600 hover:bg-emerald-700 text-white px-5 py-2 rounded-lg font-bold flex items-center space-x-1.5 transition shadow-sm cursor-pointer"
                    >
                      <Check className="w-4 h-4" />
                      <span>Aprobar Pago e Inscribir</span>
                    </button>
                  )}
                  {selectedStudent.status === 'inscrito' && (
                    <button
                      onClick={() => handleSetStatus(selectedStudent.ci, 'pre-inscrito')}
                      className="bg-amber-500 hover:bg-amber-600 text-white px-5 py-2 rounded-lg font-bold flex items-center space-x-1.5 transition shadow-sm cursor-pointer"
                    >
                      <span>Revertir a Pendiente Revisión</span>
                    </button>
                  )}
                </div>
              </div>

            </div>

          </div>
        </div>
      )}

      {/* ADD STUDENT MODAL */}
      {showAddModal && (
        <div className="fixed inset-0 bg-slate-900/60 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl border border-slate-200 shadow-2xl max-w-lg w-full overflow-hidden">
            <div className="bg-slate-900 text-white p-4 flex justify-between items-center border-b border-slate-800">
              <h3 className="font-bold text-xs uppercase tracking-wider font-mono text-amber-300">AÑADIR ESTUDIANTE ANTIGUO A BASE DE DATOS</h3>
              <button
                onClick={() => setShowAddModal(false)}
                className="text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleAddAntiguo} className="p-6 text-left text-xs font-semibold text-slate-700 space-y-4">
              <p className="text-slate-500 leading-normal text-[11px] font-normal">
                Ingrese un nuevo número de carnet de identidad para crear un alumno pre-guardado, permitiéndole testear el inicio de sesión y la verificación de deuda.
              </p>

              <div>
                <label className="block text-slate-600 mb-1">Nombre Completo del Estudiante: *</label>
                <input
                  type="text"
                  value={newAntiguo.fullName}
                  onChange={(e) => setNewAntiguo({...newAntiguo, fullName: e.target.value})}
                  className="w-full bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 text-sm text-slate-800"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-slate-600 mb-1">C.I. Estudiante: *</label>
                  <input
                    type="text"
                    value={newAntiguo.ci}
                    onChange={(e) => setNewAntiguo({...newAntiguo, ci: e.target.value})}
                    className="w-full bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 text-sm text-slate-850 font-mono"
                    placeholder="Ej: 5555555"
                    required
                  />
                </div>

                <div>
                  <label className="block text-slate-600 mb-1">Grado para el {settings.currentYear}:</label>
                  <select
                    value={newAntiguo.grade}
                    onChange={(e) => setNewAntiguo({...newAntiguo, grade: e.target.value})}
                    className="w-full bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 text-xs text-slate-800"
                  >
                    {AVAILABLE_GRADES.map((g) => (
                      <option key={g} value={g}>{g}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-slate-600 mb-1">Nombre del Tutor Legal: *</label>
                <input
                  type="text"
                  value={newAntiguo.guardianName}
                  onChange={(e) => setNewAntiguo({...newAntiguo, guardianName: e.target.value})}
                  className="w-full bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 text-sm text-slate-800"
                  required
                />
              </div>

              <div>
                <label className="inline-flex items-center text-slate-700 font-bold cursor-pointer mt-2">
                  <input
                    type="checkbox"
                    checked={newAntiguo.hasDebts}
                    onChange={(e) => setNewAntiguo({...newAntiguo, hasDebts: e.target.checked})}
                    className="text-blue-600 focus:ring-blue-500 rounded border-slate-300 w-4 h-4"
                  />
                  <span className="ml-1.5 text-[11.5px] text-red-700">¿Crear con deudas activas (Bloquear ingreso)?</span>
                </label>
              </div>

              <div className="pt-4 border-t border-slate-100 flex justify-end space-x-2">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 border border-slate-300 text-slate-600 rounded-lg hover:bg-slate-50 transition font-bold"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="bg-blue-600 hover:bg-blue-700 text-white font-bold px-5 py-2 rounded-lg transition"
                >
                  Crear Estudiante antiguo
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {showExcelModal && (
        <ExcelImporter
          currentStudents={students}
          onImportComplete={handleExcelImportComplete}
          onClose={() => setShowExcelModal(false)}
        />
      )}

    </div>
  );
}
