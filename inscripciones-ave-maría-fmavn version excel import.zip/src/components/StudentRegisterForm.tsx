import React, { useState } from 'react';
import { Student, Settings } from '../types';
import ContractViewer from './ContractViewer';
import { 
  ArrowLeft, ArrowRight, CheckCircle2, CloudUpload, FileText, 
  HelpCircle, Info, ShieldCheck, Mail, Phone, User, Landmark, Loader2 
} from 'lucide-react';

interface StudentRegisterFormProps {
  student: Student;
  settings: Settings;
  onSuccess: (updatedStudent: Student) => void;
  onCancel: () => void;
}

export default function StudentRegisterForm({
  student,
  settings,
  onSuccess,
  onCancel
}: StudentRegisterFormProps) {
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState<Student>({ ...student });
  const [isUploading, setIsUploading] = useState(false);
  const [dragActive, setDragActive] = useState(false);
  const [fileError, setFileError] = useState('');
  
  // Local states for signature values
  const [signedByName, setSignedByName] = useState('');
  const [signedDataUrl, setSignedDataUrl] = useState('');

  // Handle Form changes
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  // Drag and drop event handlers
  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFileSelected(e.dataTransfer.files[0]);
    }
  };

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      handleFileSelected(e.target.files[0]);
    }
  };

  const handleFileSelected = (file: File) => {
    setFileError('');
    if (file.type !== 'application/pdf' && !file.type.startsWith('image/')) {
      setFileError('Solo se permiten archivos en formato PDF o imágenes (JPG/PNG).');
      return;
    }

    if (file.size > 5 * 1024 * 1024) { // 5MB limit
      setFileError('El tamaño del archivo supera el límite de 5 MB.');
      return;
    }

    setIsUploading(true);

    // Read file as base64 to simulate backend storage / database attachment
    const reader = new FileReader();
    reader.onload = () => {
      setFormData(prev => ({
        ...prev,
        receiptFileName: file.name,
        receiptFileUrl: reader.result as string,
        receiptUploadedAt: new Date().toISOString()
      }));
      setIsUploading(false);
    };
    reader.onerror = () => {
      setFileError('Error al leer el archivo. Inténtelo de nuevo.');
      setIsUploading(false);
    };
    reader.readAsDataURL(file);
  };

  const handleRemoveFile = () => {
    setFormData(prev => ({
      ...prev,
      receiptFileName: null,
      receiptFileUrl: null,
      receiptUploadedAt: null
    }));
  };

  const handleSignatureComplete = (name: string, dataUrl: string) => {
    setSignedByName(name);
    setSignedDataUrl(dataUrl);
    setFormData(prev => ({
      ...prev,
      signedAt: new Date().toISOString(),
      signedByName: name,
      status: 'inscrito'
    }));
  };

  const nextStep = () => {
    if (step === 1) {
      // Validate step 1: guardian details
      if (!formData.guardianName.trim() || !formData.guardianCI.trim() || !formData.guardianPhone.trim() || !formData.guardianEmail.trim()) {
        alert('Por favor, complete todos los campos de información del tutor legal.');
        return;
      }
    }
    if (step === 2) {
      // Validate step 2: PDF/Image uploaded
      if (!formData.receiptFileName) {
        setFileError('Es obligatorio subir el PDF o imagen del comprobante de pago de la matrícula para continuar.');
        return;
      }
    }
    setStep(prev => prev + 1);
  };

  const prevStep = () => {
    setStep(prev => prev - 1);
  };

  const finishRegistration = () => {
    if (!signedDataUrl) {
      alert('Debe descargar el contrato en PDF y manifestar su conformidad para continuar.');
      return;
    }
    
    // Save to stored list
    onSuccess(formData);
  };

  const handlePrintContractOnScreen = () => {
    window.print();
  };

  return (
    <div className="w-full max-w-4xl mx-auto" id="registration-wizard-card">
      {/* Progress navigation */}
      <div className="mb-8" id="steps-progress-header">
        <div className="hidden md:flex justify-between items-center bg-slate-50 border border-slate-200 rounded-full p-1.5 shadow-sm max-w-3xl mx-auto">
          {[
            { s: 1, label: 'Datos del Tutor' },
            { s: 2, label: 'Comprobante de Pago' },
            { s: 3, label: 'Aceptación de Contrato (PDF)' },
            { s: 4, label: 'Completado' }
          ].map((item) => (
            <button
              key={item.s}
              onClick={() => {
                if (item.s < step) setStep(item.s);
              }}
              disabled={item.s >= step || step === 4}
              className={`flex-1 py-2 px-4 rounded-full text-xs font-semibold transition-all flex items-center justify-center space-x-2 ${
                step === item.s 
                  ? 'bg-blue-700 text-white shadow-md' 
                  : step > item.s 
                    ? 'text-blue-700 hover:bg-blue-50 cursor-pointer' 
                    : 'text-slate-400 cursor-not-allowed'
              }`}
            >
              <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] ${
                step === item.s ? 'bg-white text-blue-700' : 'bg-slate-200 text-slate-600'
              }`}>
                {item.s}
              </span>
              <span>{item.label}</span>
            </button>
          ))}
        </div>

        {/* Mobile progress bar indicator */}
        <div className="block md:hidden text-center bg-slate-50 border border-slate-200 p-3 rounded-xl">
          <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Pasos de Registro</span>
          <div className="text-lg font-bold text-slate-800 mt-1">Paso {step} de 4</div>
          <div className="w-full bg-slate-200 h-2 rounded-full overflow-hidden mt-2">
            <div className="bg-blue-600 h-full transition-all duration-300" style={{ width: `${(step / 4) * 100}%` }} />
          </div>
        </div>
      </div>

      <div className="bg-white border border-slate-200 rounded-2xl shadow-lg p-6 md:p-8">
        
        {/* Step 1: CONFIRMAR DATOS TUTOR/ESTUDIANTE */}
        {step === 1 && (
          <div className="space-y-6">
            <div className="border-b border-slate-100 pb-4">
              <h3 className="text-lg font-bold text-slate-800 flex items-center space-x-2">
                <User className="w-5 h-5 text-blue-600" />
                <span>Paso 1: Ratificación de Datos del Estudiante</span>
              </h3>
              <p className="text-xs text-slate-500 mt-1">Verifique la información preestablecida del estudiante y actualice los datos de contacto de su tutor legal.</p>
            </div>

            {/* Read-only Student Info */}
            <div className="bg-slate-50/80 border border-slate-150 rounded-xl p-5 mb-4 grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <span className="block text-[11px] font-semibold text-slate-400 uppercase">Estudiante:</span>
                <span className="text-sm font-bold text-slate-800 uppercase">{formData.fullName}</span>
              </div>
              <div>
                <span className="block text-[11px] font-semibold text-slate-400 uppercase">Documento / C.I.:</span>
                <span className="text-sm font-mono font-medium text-slate-700">{formData.ci}</span>
              </div>
              <div>
                <span className="block text-[11px] font-semibold text-slate-400 uppercase">Grado para el {settings.currentYear}:</span>
                <span className="text-sm font-bold text-blue-800 bg-blue-50 px-2.5 py-0.5 rounded-full inline-block mt-0.5">{formData.grade}</span>
              </div>
            </div>

            <div className="space-y-4">
              <h4 className="text-xs font-bold text-slate-600 uppercase tracking-wide border-b border-slate-100 pb-1.5">Información Requerida del Tutor Legal</h4>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-600 mb-1.5">Nombre Completo del Tutor Legal:</label>
                  <div className="relative">
                    <input
                      type="text"
                      name="guardianName"
                      value={formData.guardianName}
                      onChange={handleInputChange}
                      className="w-full bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 text-sm text-slate-800 focus:outline-none focus:ring-2 focus:ring-blue-600 focus:bg-white focus:border-transparent transition"
                      required
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-600 mb-1.5">Carnet de Identidad del Tutor (C.I.):</label>
                  <input
                    type="text"
                    name="guardianCI"
                    value={formData.guardianCI}
                    onChange={handleInputChange}
                    className="w-full bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 text-sm text-slate-800 focus:outline-none focus:ring-2 focus:ring-blue-600 focus:bg-white focus:border-transparent transition"
                    required
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-600 mb-1.5">Número de Celular de Contacto:</label>
                  <div className="relative">
                    <span className="absolute inset-y-0 left-0 pl-3 flex items-center text-slate-500 text-xs font-medium">
                      <Phone className="w-4 h-4 text-slate-400 mr-1" />
                    </span>
                    <input
                      type="text"
                      name="guardianPhone"
                      value={formData.guardianPhone}
                      onChange={handleInputChange}
                      className="w-full pl-8 bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 text-sm text-slate-800 focus:outline-none focus:ring-2 focus:ring-blue-600 focus:bg-white focus:border-transparent transition"
                      required
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-600 mb-1.5">Correo Electrónico del Tutor:</label>
                  <div className="relative">
                    <span className="absolute inset-y-0 left-0 pl-3 flex items-center text-slate-500 text-xs font-medium">
                      <Mail className="w-4 h-4 text-slate-400 mr-1" />
                    </span>
                    <input
                      type="email"
                      name="guardianEmail"
                      value={formData.guardianEmail}
                      onChange={handleInputChange}
                      className="w-full pl-8 bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 text-sm text-slate-800 focus:outline-none focus:ring-2 focus:ring-blue-600 focus:bg-white focus:border-transparent transition"
                      required
                    />
                  </div>
                </div>
              </div>
            </div>

            <div className="pt-6 border-t border-slate-100 flex justify-between">
              <button
                type="button"
                onClick={onCancel}
                className="px-5 py-2 border border-slate-300 hover:bg-slate-50 text-slate-600 rounded-lg text-sm transition font-medium"
              >
                Volver al Inicio
              </button>
              <button
                type="button"
                onClick={nextStep}
                className="bg-blue-700 hover:bg-blue-800 text-white font-medium text-sm px-6 py-2 rounded-lg flex items-center space-x-2 transition shadow-sm"
              >
                <span>Siguiente: Cargar Pago</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* Step 2: COMPROBANTE DE PAGO PDF COBRANZA */}
        {step === 2 && (
          <div className="space-y-6">
            <div className="border-b border-slate-100 pb-4">
              <h3 className="text-lg font-bold text-slate-800 flex items-center space-x-2">
                <Landmark className="w-5 h-5 text-blue-600" />
                <span>Paso 2: Comprobante de Pago de Matrícula (PDF)</span>
              </h3>
              <p className="text-xs text-slate-500 mt-1">
                Para el proceso de ratificación o inscripción {settings.currentYear}, debe cancelar el costo de matrícula anual ({settings.matriculaAmount} Bs.) y subir el comprobante bancario.
              </p>
            </div>

            {/* Bank Details Accent */}
            <div className="bg-amber-50/50 border border-amber-200/60 rounded-xl p-5 mb-5 space-y-3">
              <h4 className="text-xs font-bold text-amber-800 flex items-center space-x-1.5 uppercase">
                <Landmark className="w-4 h-4 text-amber-600" />
                <span>Instrucciones de Transferencia o Depósito de Banco</span>
              </h4>
              <p className="text-xs text-slate-600 leading-relaxed">
                Realice el depósito o transferencia bancaria antes de continuar. Aceptamos archivos <strong>PDF</strong> o <strong>imágenes legibles (.jpg, .png)</strong> de su recibo o captura electrónica.
              </p>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-1 text-xs">
                <div className="bg-white p-2.5 rounded-lg border border-slate-150">
                  <span className="block font-semibold text-slate-400">Banco Receptor:</span>
                  <span className="font-bold text-slate-800">{settings.bankInfo.bankName}</span>
                </div>
                <div className="bg-white p-2.5 rounded-lg border border-slate-150">
                  <span className="block font-semibold text-slate-400">Número de Cuenta:</span>
                  <span className="font-mono font-bold text-[13px] text-blue-700">{settings.bankInfo.accountNumber}</span>
                </div>
                <div className="bg-white p-2.5 rounded-lg border border-slate-150">
                  <span className="block font-semibold text-slate-400">Razón Social:</span>
                  <span className="font-bold text-slate-800">{settings.bankInfo.accountHolder}</span>
                </div>
                <div className="bg-white p-2.5 rounded-lg border border-slate-150">
                  <span className="block font-semibold text-slate-400">Monto Matrícula:</span>
                  <span className="font-bold text-emerald-700 text-sm">{settings.matriculaAmount} Bs.</span>
                </div>
              </div>
            </div>

            {/* Document upload zone */}
            <div className="space-y-4">
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide">Comprobante de pago PDF o Imagen:</label>
              
              {!formData.receiptFileName ? (
                <div
                  onDragEnter={handleDrag}
                  onDragOver={handleDrag}
                  onDragLeave={handleDrag}
                  onDrop={handleDrop}
                  className={`border-2 border-dashed rounded-xl p-8 text-center flex flex-col items-center justify-center transition-all ${
                    dragActive 
                      ? 'border-blue-500 bg-blue-50/50 scale-102' 
                      : 'border-slate-300 hover:border-blue-400 bg-slate-50/30'
                  }`}
                >
                  {isUploading ? (
                    <div className="space-y-3 py-4">
                      <Loader2 className="w-10 h-10 text-blue-600 animate-spin mx-auto" />
                      <p className="text-sm font-semibold text-slate-600">Procesando y validando archivo...</p>
                    </div>
                  ) : (
                    <div className="space-y-3">
                      <div className="w-12 h-12 bg-blue-50 text-blue-600 rounded-full flex items-center justify-center mx-auto">
                        <CloudUpload className="w-6 h-6" />
                      </div>
                      <div>
                        <p className="text-sm font-bold text-slate-700">Arrastre y suelte su archivo comprobante aquí</p>
                        <p className="text-xs text-slate-400 mt-1">O haga clic para navegar localmente (Límite: 5MB)</p>
                      </div>
                      
                      <label className="inline-block bg-blue-700 hover:bg-blue-800 text-white font-medium text-xs px-4 py-2 rounded-lg cursor-pointer transition shadow-sm">
                        <span>Seleccionar Archivo</span>
                        <input
                          type="file"
                          accept="application/pdf,image/*"
                          onChange={handleFileInput}
                          className="hidden"
                        />
                      </label>
                      
                      <div className="flex justify-center space-x-4 pt-2 text-[10px] text-slate-400 font-mono">
                        <span>Soporta: PDF</span>
                        <span>•</span>
                        <span>Soporta: PNG, JPG, GIF</span>
                      </div>
                    </div>
                  )}
                </div>
              ) : (
                <div className="bg-emerald-50/50 border border-emerald-200 rounded-xl p-4 flex items-center justify-between">
                  <div className="flex items-center space-x-3 overflow-hidden">
                    <div className="w-11 h-11 bg-emerald-100 text-emerald-800 rounded-lg flex items-center justify-center shrink-0">
                      <FileText className="w-6 h-6" />
                    </div>
                    <div className="text-left overflow-hidden">
                      <p className="text-xs font-bold text-slate-700 truncate">{formData.receiptFileName}</p>
                      <p className="text-[10px] text-emerald-600 mt-0.5">
                        ✓ Cargado con éxito • {formData.receiptUploadedAt ? new Date(formData.receiptUploadedAt).toLocaleTimeString() : ''}
                      </p>
                    </div>
                  </div>
                  
                  <button
                    onClick={handleRemoveFile}
                    className="text-xs text-red-500 hover:bg-red-50 hover:text-red-700 px-3 py-1.5 rounded-lg border border-transparent hover:border-red-100 transition-all font-medium"
                  >
                    Quitar archivo
                  </button>
                </div>
              )}

              {fileError && (
                <p className="text-xs text-red-500 font-medium bg-red-50 px-3 py-1.5 rounded border border-red-100">
                  ⚠️ {fileError}
                </p>
              )}

              {/* Optional verification commentary */}
              <div>
                <label className="block text-xs font-semibold text-slate-600 mb-1.5">Firma / Glosa / Comentario del Depósito (Opcional):</label>
                <input
                  type="text"
                  name="paymentNotes"
                  value={formData.paymentNotes || ''}
                  onChange={handleInputChange}
                  placeholder="Ej: Número de transferencia, nombre de titular de la cuenta de origen..."
                  className="w-full bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-blue-600 focus:bg-white focus:border-transparent transition"
                />
              </div>
            </div>

            <div className="pt-6 border-t border-slate-100 flex justify-between">
              <button
                type="button"
                onClick={prevStep}
                className="px-5 py-2 border border-slate-300 hover:bg-slate-50 text-slate-600 rounded-lg text-sm transition"
              >
                Retroceder
              </button>
              <button
                type="button"
                onClick={nextStep}
                className="bg-blue-700 hover:bg-blue-800 text-white font-medium text-sm px-6 py-2 rounded-lg flex items-center space-x-2 transition shadow-sm"
              >
                <span>Siguiente: Contrato PDF</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* Step 3: DESCARGAR Y ACEPTAR CONTRATO DE SERVICIOS EDUCATIVOS */}
        {step === 3 && (
          <div className="space-y-6">
            <div className="border-b border-slate-100 pb-4">
              <h3 className="text-lg font-bold text-slate-800 flex items-center space-x-2">
                <ShieldCheck className="w-5 h-5 text-blue-600" />
                <span>Paso 3: Lectura y Descarga del Contrato en PDF</span>
              </h3>
              <p className="text-xs text-slate-500 mt-1">
                Proceda al análisis del Contrato de Prestación de Servicios de la Gestión Educativa {settings.currentYear}. Es indispensable que rellene su Domicilio y descargue el documento de contrato en PDF como constancia obligatoria.
              </p>
            </div>

            <ContractViewer
              student={formData}
              settings={settings}
              onSign={handleSignatureComplete}
              savedSignature={signedDataUrl}
            />

            <div className="pt-6 border-t border-slate-100 flex justify-between">
              <button
                type="button"
                onClick={prevStep}
                className="px-5 py-2 border border-slate-300 hover:bg-slate-50 text-slate-600 rounded-lg text-sm transition"
              >
                Retroceder
              </button>
              <button
                type="button"
                onClick={finishRegistration}
                disabled={!signedDataUrl}
                className={`font-semibold text-sm px-7 py-2.5 rounded-lg flex items-center space-x-2 transition shadow-sm ${
                  signedDataUrl 
                    ? 'bg-emerald-600 hover:bg-emerald-700 text-white cursor-pointer' 
                    : 'bg-slate-100 text-slate-400 cursor-not-allowed border border-slate-200'
                }`}
              >
                <span>Finalizar Ratificación Escolar</span>
                <CheckCircle2 className="w-4.5 h-4.5" />
              </button>
            </div>
          </div>
        )}

        {/* Step 4: SUCCESS COMPLETED */}
        {step === 4 && (
          <div className="text-center py-8 space-y-6 max-w-lg mx-auto" id="registration-finished-panel">
            <div className="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto border-4 border-emerald-50">
              <CheckCircle2 className="w-10 h-10" />
            </div>

            <div className="space-y-2">
              <h3 className="text-2xl font-bold text-slate-800">¡Ratificación Completada!</h3>
              <p className="text-sm text-slate-500">
                El proceso de ratificación o inscripción electrónica de <strong className="text-slate-800 uppercase">{formData.fullName}</strong> se ha procesado con total conformidad legal en los servidores de la institución <strong>{settings.schoolName}</strong>.
              </p>
            </div>

            {/* Print Card Visual Summary */}
            <div className="bg-slate-50 border border-slate-200 rounded-xl p-5 text-left text-xs space-y-3 font-medium">
              <div className="flex justify-between items-center pb-2 border-b border-slate-200">
                <span className="font-bold text-slate-400 uppercase tracking-wide text-[10px]">Constancia Escolar</span>
                <span className="text-emerald-700 font-bold bg-emerald-50 px-2 py-0.5 rounded-full text-[10px]">TRAMITE ONLINE</span>
              </div>
              <div className="grid grid-cols-2 gap-y-2 text-slate-600">
                <div>
                  <span className="block text-[10px] text-slate-400 font-bold uppercase">Estudiante:</span>
                  <span className="font-bold text-slate-800 leading-tight block">{formData.fullName}</span>
                </div>
                <div>
                  <span className="block text-[10px] text-slate-400 font-bold uppercase">Grado Ratificado:</span>
                  <span className="font-bold text-slate-800 block">{formData.grade}</span>
                </div>
                <div>
                  <span className="block text-[10px] text-slate-400 font-bold uppercase">C.I. Estudiante:</span>
                  <span className="font-mono text-slate-800 text-[11px] font-bold block">{formData.ci}</span>
                </div>
                <div>
                  <span className="block text-[10px] text-slate-400 font-bold uppercase">Tutor Firmante:</span>
                  <span className="font-semibold text-slate-800 block">{signedByName || formData.guardianName}</span>
                </div>
                <div className="col-span-2 pt-1">
                  <span className="block text-[10px] text-slate-400 font-bold uppercase">Comprobante de Pago Matrícula:</span>
                  <span className="text-slate-700 italic block font-bold mt-0.5">📄 {formData.receiptFileName}</span>
                </div>
              </div>
            </div>

            <div className="p-4 bg-blue-50 border border-blue-100 rounded-xl text-left text-xs text-blue-800 flex items-start space-x-2">
              <Info className="w-4.5 h-4.5 text-blue-600 shrink-0 mt-0.5" />
              <div className="leading-relaxed">
                <strong>¿Qué sigue ahora?</strong> La dirección de admisiones de la institución validará el comprobante bancario adjuntado. Recibirá un correo a <strong className="underline">{formData.guardianEmail}</strong> con el contrato firmado en formato PDF formal en las próximas 48 horas coordinándose el inicio de la gestión escolar {settings.currentYear}.
              </div>
            </div>

            <div className="flex flex-col sm:flex-row space-y-3 sm:space-y-0 sm:space-x-3 justify-center pt-2">
              <button
                type="button"
                onClick={handlePrintContractOnScreen}
                className="bg-white border border-slate-300 hover:border-blue-500 hover:text-blue-700 text-slate-700 px-5 py-2.5 rounded-lg text-sm font-medium flex items-center justify-center space-x-2 transition shadow-sm w-full sm:w-auto"
              >
                <FileText className="w-4 h-4" />
                <span>Imprimir Contrato</span>
              </button>
              <button
                type="button"
                onClick={onCancel}
                className="bg-blue-700 hover:bg-blue-800 text-white px-6 py-2.5 rounded-lg text-sm font-bold flex items-center justify-center space-x-2 transition shadow-md w-full sm:w-auto"
              >
                <span>Finalizar e Ir al Inicio</span>
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
