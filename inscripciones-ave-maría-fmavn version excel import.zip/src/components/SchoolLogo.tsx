import React from 'react';

interface SchoolLogoProps {
  className?: string;
  showText?: boolean;
  variant?: 'light' | 'dark' | 'appbar';
}

export default function SchoolLogo({
  className = "w-16 h-16",
  showText = false,
  variant = "light"
}: SchoolLogoProps) {
  return (
    <div className="flex flex-col items-center justify-center">
      {/* Ruta a tu imagen de logo */}
      <img 
        src="logo.png"       // Cambia esto a la ubicación de tu imagen
        alt="U.E. Ave María" 
        className={`${className} object-contain`}
        referrerPolicy="no-referrer"
      />

      {showText && (
        <div className={`mt-3.5 text-center select-none ${variant === "dark" ? "text-white" : "text-slate-800"}`}>
          <h3 className="font-extrabold tracking-[0.14em] text-[13px] leading-tight uppercase font-sans">
            U.E. Ave María
          </h3>
          <p className={`font-semibold tracking-[0.08em] text-[10px] uppercase mt-1 ${variant === "dark" ? "text-blue-200" : "text-blue-700 font-bold"}`}>
            Fundación Manos Abiertas
          </p>
          <p className={`font-bold tracking-[0.05em] text-[9.5px] uppercase mt-0.5 ${variant === "dark" ? "text-amber-300" : "text-amber-700"}`}>
            Virgen de la Natividad
          </p>
        </div>
      )}
    </div>
  );
}