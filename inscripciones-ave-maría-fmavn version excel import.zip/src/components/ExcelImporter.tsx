import React, { useState, useRef } from 'react';
import * as XLSX from 'xlsx';
import { Student } from '../types';
import { 
  FileSpreadsheet, Upload, Download, CheckCircle, 
  AlertTriangle, Trash2, HelpCircle, RefreshCw, X 
} from 'lucide-react';
import { AVAILABLE_GRADES } from '../data';

interface ExcelImporterProps {
  onImportComplete: (importedStudents: Student[], mode: 'append' | 'replace') => void;
  onClose: () => void;
  currentStudents: Student[];
}

export default function ExcelImporter({ onImportComplete, onClose, currentStudents }: ExcelImporterProps) {
  const [dragActive, setDragActive] = useState(false);
  const [parsedData, setParsedData] = useState<any[]>([]);
  const [headers, setHeaders] = useState<string[]>([]);
  const [fileName, setFileName] = useState('');
  const [mappedStudents, setMappedStudents] = useState<Student[]>([]);
  const [validationErrors, setValidationErrors] = useState<{ row: number; error: string }[]>([]);
  const [importMode, setImportMode] = useState<'append' | 'replace'>('append');
  const [previewOpen, setPreviewOpen] = useState(false);
  
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Download a real xlsx template file dynamically
  const downloadTemplate = () => {
    const templateHeaders = [
      'C.I. Estudiante',
      'Nombre Completo Estudiante',
      'Curso',
      'Género (M o F)',
      'Tiene Deudas (SI o NO)',
      'Nombre del Tutor Legal',
      'C.I. del Tutor',
      'Teléfono del Tutor',
      'Correo del Tutor',
      'Meses de Deuda (Opcional - separados por comas)',
      'Monto de Deuda Total (Opcional)'
    ];

    const sampleRows = [
      [
        '7777777',
        'Kamila Vargas Blanco',
        '2do de Secundaria',
        'F',
        'NO',
        'María Mercedes Blanco',
        '4820194',
        '70582910',
        'maria.blanco@gmail.com',
        '',
        ''
      ],
      [
        '1234567',
        'Mateo Ortiz Quispe',
        '5to de Primaria',
        'M',
        'SI',
        'Jorge Ortiz Huanca',
        '3920184',
        '68042910',
        'jorge.ortiz@outlook.com',
        'Pensiones Marzo 2026, Pensiones Abril 2026',
        '900'
      ],
      [
        '8888888',
        'Sebastian Choque Gomez',
        '6to de Primaria',
        'M',
        'NO',
        'René Choque Calle',
        '5938104',
        '71283940',
        'rene.choque@hotmail.com',
        '',
        ''
      ]
    ];

    const ws = XLSX.utils.aoa_to_sheet([templateHeaders, ...sampleRows]);
    
    // Set some column widths for aesthetics
    ws['!cols'] = [
      { wch: 15 }, // C.I. Estudiante
      { wch: 30 }, // Nombre Completo
      { wch: 20 }, // Curso
      { wch: 15 }, // Género
      { wch: 20 }, // Tiene Deudas
      { wch: 28 }, // Nombre del Tutor
      { wch: 15 }, // C.I. del Tutor
      { wch: 18 }, // Teléfono
      { wch: 25 }, // Correo
      { wch: 32 }, // Meses deuda
      { wch: 20 }  // Monto deuda
    ];

    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Estudiantes');
    XLSX.writeFile(wb, 'Plantilla_Importar_Estudiantes.xlsx');
  };

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);

    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      processFile(e.dataTransfer.files[0]);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      processFile(e.target.files[0]);
    }
  };

  const cleanHeader = (h: string): string => {
    return h.toString()
      .trim()
      .toLowerCase()
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "") // remove tildes
      .replace(/[^a-z0-9]/g, ""); // keep alphanumeric
  };

  // Find index or value based on closest column header names
  const findColumnValue = (row: any, keys: string[]): any => {
    for (const rawKey of Object.keys(row)) {
      const clsKey = cleanHeader(rawKey);
      if (keys.some(k => clsKey.includes(k) || k.includes(clsKey))) {
        return row[rawKey];
      }
    }
    return undefined;
  };

  // Helper fuzzy matcher for grades
  const normalizeGrade = (gradeVal: any): string => {
    if (!gradeVal) return AVAILABLE_GRADES[0];
    const rawVal = gradeVal.toString().trim().toLowerCase();
    
    // Exact or direct match
    const found = AVAILABLE_GRADES.find(g => g.toLowerCase() === rawVal || g.toLowerCase().includes(rawVal));
    if (found) return found;

    // Numerical mappings
    if (rawVal.includes('1') && rawVal.includes('sec')) return '1ro de Secundaria';
    if (rawVal.includes('2') && rawVal.includes('sec')) return '2do de Secundaria';
    if (rawVal.includes('3') && rawVal.includes('sec')) return '3ro de Secundaria';
    if (rawVal.includes('4') && rawVal.includes('sec')) return '4to de Secundaria';
    if (rawVal.includes('5') && rawVal.includes('sec')) return '5to de Secundaria';
    if (rawVal.includes('6') && rawVal.includes('sec')) return '6to de Secundaria';

    if (rawVal.includes('1') && rawVal.includes('pri')) return '1ro de Primaria';
    if (rawVal.includes('2') && rawVal.includes('pri')) return '2do de Primaria';
    if (rawVal.includes('3') && rawVal.includes('pri')) return '3ro de Primaria';
    if (rawVal.includes('4') && rawVal.includes('pri')) return '4to de Primaria';
    if (rawVal.includes('5') && rawVal.includes('pri')) return '5to de Primaria';
    if (rawVal.includes('6') && rawVal.includes('pri')) return '6to de Primaria';

    if (rawVal.includes('kinder')) return 'Inicial - Kinder';
    if (rawVal.includes('pre') && rawVal.includes('kinder')) return 'Inicial - Pre-Kinder';

    return AVAILABLE_GRADES[0]; // fallback
  };

  const processFile = (file: File) => {
    setFileName(file.name);
    const reader = new FileReader();

    reader.onload = (e) => {
      try {
        const data = e.target?.result;
        if (!data) return;
        
        const wb = XLSX.read(data, { type: 'binary' });
        const sheetName = wb.SheetNames[0];
        const sheet = wb.Sheets[sheetName];
        
        // Convert sheet to JSON rows
        const rawJson: any[] = XLSX.utils.sheet_to_json(sheet, { defval: '' });
        
        if (rawJson.length === 0) {
          alert('El archivo cargado está vacío o no tiene el formato correcto.');
          return;
        }

        setHeaders(Object.keys(rawJson[0]));
        setParsedData(rawJson);
        mapRowsToStudents(rawJson);
      } catch (err: any) {
        console.error(err);
        alert('Error al leer el archivo. Asegúrese de que sea un archivo Excel válido (.xlsx, .xls) o un CSV.');
      }
    };

    reader.readAsBinaryString(file);
  };

  const mapRowsToStudents = (rows: any[]) => {
    const errorLog: { row: number; error: string }[] = [];
    const mapped: Student[] = [];

    // Define dictionary keywords for auto mapping
    const MAPPINGS = {
      ci: ['ciestudiante', 'ci', 'carnet', 'documento', 'cedula', 'identificacion'],
      fullName: ['nombrecompletoestudiante', 'nombre', 'nombrecompleto', 'alumno', 'estudiante', 'fullname', 'nombres'],
      grade: ['curso', 'grado', 'nivel', 'grade'],
      gender: ['genero', 'sexo', 'gender', 'fm', 'mf'],
      hasDebts: ['tienedeudas', 'tienedeuda', 'mora', 'deuda', 'debiendo', 'hasdebts', 'debts'],
      guardianName: ['nombretutor', 'nombredeltutor', 'nombretutorlegal', 'tutor', 'padre', 'madre', 'guardian', 'guardianname'],
      guardianCI: ['citutor', 'citutorlegal', 'cedulatutor', 'carnettutor', 'guardianci'],
      guardianPhone: ['telefono', 'celular', 'telefonotutor', 'celulartutor', 'guardianphone'],
      guardianEmail: ['correo', 'email', 'mail', 'correotutor', 'correodeltutor', 'guardianemail'],
      pendingMonths: ['meses', 'mesesdeuda', 'mesesdemora', 'pendingmonths'],
      totalDebtAmount: ['monto', 'montoquebe', 'montodeuda', 'deudatotal', 'totaldebtamount']
    };

    rows.forEach((row, index) => {
      const rowNum = index + 1;

      // Extract values with resilient fuzzy dictionaries
      const ciRaw = findColumnValue(row, MAPPINGS.ci);
      const fullNameRaw = findColumnValue(row, MAPPINGS.fullName);
      const gradeRaw = findColumnValue(row, MAPPINGS.grade);
      const genderRaw = findColumnValue(row, MAPPINGS.gender);
      const hasDebtsRaw = findColumnValue(row, MAPPINGS.hasDebts);
      
      const guardianNameRaw = findColumnValue(row, MAPPINGS.guardianName);
      const guardianCIRaw = findColumnValue(row, MAPPINGS.guardianCI);
      const guardianPhoneRaw = findColumnValue(row, MAPPINGS.guardianPhone);
      const guardianEmailRaw = findColumnValue(row, MAPPINGS.guardianEmail);
      
      const pendingMonthsRaw = findColumnValue(row, MAPPINGS.pendingMonths);
      const totalDebtAmountRaw = findColumnValue(row, MAPPINGS.totalDebtAmount);

      // VALIDATIONS
      if (!ciRaw) {
        errorLog.push({ row: rowNum, error: 'Falta "C.I." del estudiante' });
        return;
      }
      
      const ci = ciRaw.toString().trim();
      if (!fullNameRaw) {
        errorLog.push({ row: rowNum, error: `Falta "Nombre Completo del Estudiante" en fila del C.I. ${ci}` });
        return;
      }

      const fullName = fullNameRaw.toString().trim();

      // Normalize gender key
      let gender: 'M' | 'F' = 'M';
      if (genderRaw) {
        const cleanedG = genderRaw.toString().trim().toUpperCase();
        if (cleanedG.startsWith('F') || cleanedG.startsWith('M')) {
          gender = cleanedG.startsWith('F') ? 'F' : 'M';
        }
      }

      // Deudas interpretation
      let hasDebts = false;
      if (hasDebtsRaw) {
        const cdStr = hasDebtsRaw.toString().trim().toUpperCase();
        if (cdStr === 'SI' || cdStr === 'SÍ' || cdStr === 'TRUE' || cdStr === 'VERDADERO' || cdStr === '1' || cdStr === 'DEUDA') {
          hasDebts = true;
        }
      }

      // Pending months format parsing
      let pendingMonths: string[] | undefined = undefined;
      if (hasDebts && pendingMonthsRaw) {
        pendingMonths = pendingMonthsRaw.toString().split(/[,;]/).map((m: string) => m.trim()).filter((m: string) => m.length > 0);
      } else if (hasDebts) {
        pendingMonths = ['Pensiones Gestión Escolar'];
      }

      // Debt Amount
      let totalDebtAmount: number | undefined = undefined;
      if (hasDebts) {
        const amt = parseFloat(totalDebtAmountRaw);
        totalDebtAmount = !isNaN(amt) && amt > 0 ? amt : 900; // default standard old debt
      }

      const studentData: Student = {
        ci,
        fullName,
        grade: normalizeGrade(gradeRaw),
        gender,
        birthDate: '2014-04-10', // Standard generic date mapping
        hasDebts,
        pendingMonths,
        totalDebtAmount,
        guardianName: guardianNameRaw ? guardianNameRaw.toString().trim() : 'Tutor por Registrar',
        guardianCI: guardianCIRaw ? guardianCIRaw.toString().trim() : '4900000',
        guardianPhone: guardianPhoneRaw ? guardianPhoneRaw.toString().trim() : '70000000',
        guardianEmail: guardianEmailRaw ? guardianEmailRaw.toString().trim() : 'tutor@example.com',
        status: 'pendiente',
        type: 'antiguo'
      };

      mapped.push(studentData);
    });

    setMappedStudents(mapped);
    setValidationErrors(errorLog);
    setPreviewOpen(true);
  };

  const handleImportExecute = () => {
    if (mappedStudents.length === 0) {
      alert('No hay estudiantes válidos para importar.');
      return;
    }

    onImportComplete(mappedStudents, importMode);
    onClose();
  };

  const clearFile = () => {
    setFileName('');
    setParsedData([]);
    setHeaders([]);
    setMappedStudents([]);
    setValidationErrors([]);
    setPreviewOpen(false);
  };

  return (
    <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 overflow-y-auto" id="excel-importer-modal">
      <div className="bg-white rounded-2xl border border-slate-200 shadow-2xl max-w-4xl w-full max-h-[90vh] flex flex-col overflow-hidden">
        
        {/* Modal Header */}
        <div className="bg-slate-900 px-6 py-4 text-white flex items-center justify-between shadow-md">
          <div className="flex items-center space-x-3">
            <FileSpreadsheet className="w-5 h-5 text-emerald-400 animate-pulse" />
            <div>
              <h3 className="font-bold text-sm tracking-wide uppercase font-mono">Importar Estudiantes desde Excel</h3>
              <p className="text-[10px] text-slate-400">Agregación masiva de estudiantes a la base de datos local</p>
            </div>
          </div>
          <button 
            type="button" 
            onClick={onClose} 
            className="text-slate-400 hover:text-white transition p-1 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal body */}
        <div className="p-6 overflow-y-auto flex-1 space-y-6">
          
          {/* Instructions and Download Block */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-5 bg-slate-50 p-4 rounded-xl border border-slate-150">
            <div className="md:col-span-2 text-xs leading-relaxed text-slate-600 space-y-1.5 p-1">
              <span className="font-extrabold text-slate-800 text-sm block">Guía de Formato de Archivo</span>
              <p>El importador es inteligente y mapea los encabezados de forma automática, pero procure contar con las siguientes columnas:</p>
              <ul className="list-disc pl-5 text-[11px] text-slate-500 space-y-0.5">
                <li><strong>C.I. Estudiante:</strong> Carnet de identidad oficial (Único).</li>
                <li><strong>Nombre Completo:</strong> Apellidos y nombres del alumno.</li>
                <li><strong>Curso:</strong> Grado oficial (Ej: <em>2do de Secundaria</em>, <em>Kinder de Inicial</em>).</li>
                <li><strong>Tiene Deudas:</strong> Coloque <em>SI</em>, <em>NO</em>, o deje en blanco.</li>
                <li><strong>Tutor Legal:</strong> Datos del tutor (Nombre, C.I., Teléfono, Correo).</li>
              </ul>
            </div>
            
            <div className="flex flex-col items-center justify-center p-4 bg-white border border-slate-200 rounded-xl shadow-sm text-center">
              <HelpCircle className="w-8 h-8 text-blue-600 mb-2" />
              <button
                type="button"
                onClick={downloadTemplate}
                className="w-full bg-emerald-700 hover:bg-emerald-800 text-white text-[11px] font-bold py-2 px-3 rounded-lg flex items-center justify-center space-x-1.5 transition cursor-pointer"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Descargar Plantilla Excel</span>
              </button>
              <span className="text-[9px] text-slate-400 mt-1.5">Descarga el formato modelo xlsx oficial</span>
            </div>
          </div>

          {/* Upload Area */}
          {!fileName ? (
            <div
              onDragEnter={handleDrag}
              onDragOver={handleDrag}
              onDragLeave={handleDrag}
              onDrop={handleDrop}
              onClick={() => fileInputRef.current?.click()}
              className={`border-2 border-dashed rounded-xl py-10 px-6 text-center cursor-pointer flex flex-col items-center justify-center transition-all ${
                dragActive 
                  ? 'border-blue-600 bg-blue-50/50' 
                  : 'border-slate-350 bg-slate-50/30 hover:bg-slate-50'
              }`}
            >
              <input
                ref={fileInputRef}
                type="file"
                accept=".xlsx, .xls, .csv"
                onChange={handleFileChange}
                className="hidden"
              />
              <Upload className="w-12 h-12 text-slate-400 mb-3" />
              <span className="text-xs font-bold text-slate-700">Arrastre aquí su archivo Excel o haga clic para buscar</span>
              <span className="text-[10px] text-slate-400 mt-1">Formatos permitidos: .xlsx, .xls, .csv (Tamaño máx. 5MB)</span>
            </div>
          ) : (
            <div className="flex items-center justify-between p-4 border border-blue-200 bg-blue-50/40 rounded-xl">
              <div className="flex items-center space-x-3">
                <div className="bg-emerald-100 p-2.5 rounded-lg border border-emerald-200">
                  <FileSpreadsheet className="w-6 h-6 text-emerald-800" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-slate-800 truncate max-w-[300px]">{fileName}</h4>
                  <p className="text-[10px] text-slate-500">{parsedData.length} filas detectadas en el documento</p>
                </div>
              </div>
              <button
                type="button"
                onClick={clearFile}
                className="p-1.5 bg-slate-100 text-slate-600 border border-slate-200 rounded-lg hover:bg-red-50 hover:text-red-700 hover:border-red-100 transition cursor-pointer flex items-center space-x-1"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span className="text-[10px] font-bold">Cambiar de Archivo</span>
              </button>
            </div>
          )}

          {/* Preview grid */}
          {previewOpen && (
            <div className="space-y-4">
              
              {/* Errors alert box if any */}
              {validationErrors.length > 0 && (
                <div className="p-3.5 bg-amber-50 border border-amber-150 rounded-xl text-amber-900 leading-normal text-xs space-y-1.5">
                  <div className="flex items-center space-x-2 font-bold text-amber-800">
                    <AlertTriangle className="w-4.5 h-4.5 text-amber-600" />
                    <span>Se omitieron {validationErrors.length} filas con inconsistencias:</span>
                  </div>
                  <div className="max-h-[80px] overflow-y-auto pl-6 font-mono text-[10px] space-y-1">
                    {validationErrors.slice(0, 5).map((e, idx) => (
                      <p key={idx}>Fila {e.row}: {e.error}</p>
                    ))}
                    {validationErrors.length > 5 && (
                      <p>... y otros {validationErrors.length - 5} errores de validación.</p>
                    )}
                  </div>
                </div>
              )}

              {/* Import options */}
              <div className="p-4 border border-slate-200 rounded-xl flex flex-col md:flex-row md:items-center md:justify-between gap-4 bg-slate-50/50">
                <div>
                  <span className="text-xs font-bold text-slate-800 block">Modo de Configuración de Importación</span>
                  <span className="text-[10.5px] text-slate-500 mt-0.5 block">¿Cómo deben incorporarse los estudiantes importados?</span>
                </div>
                <div className="flex items-center space-x-2">
                  <button
                    type="button"
                    onClick={() => setImportMode('append')}
                    className={`px-3 py-2 rounded-lg text-xs font-bold border transition-colors cursor-pointer ${
                      importMode === 'append'
                        ? 'bg-blue-600 text-white border-blue-600 shadow-sm'
                        : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                    }`}
                  >
                    Mantener actuales e incorporar nuevos
                  </button>
                  <button
                    type="button"
                    onClick={() => setImportMode('replace')}
                    className={`px-3 py-2 rounded-lg text-xs font-bold border transition-colors cursor-pointer ${
                      importMode === 'replace'
                        ? 'bg-red-600 text-white border-red-600 shadow-sm'
                        : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                    }`}
                  >
                    Sobrescribir base de datos actual ({currentStudents.length})
                  </button>
                </div>
              </div>

              {/* Parsed List Preview Grid */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-bold text-slate-700 uppercase tracking-wide">Estudiantes a registrar ({mappedStudents.length})</span>
                  <span className="text-[10px] text-slate-400 blink">Mapeo completado</span>
                </div>
                
                <div className="border border-slate-200 rounded-xl overflow-hidden max-h-[220px] overflow-y-auto">
                  <table className="w-full text-left text-[11px] border-collapse bg-white">
                    <thead>
                      <tr className="bg-slate-100 font-bold text-slate-500 border-b border-slate-200">
                        <th className="p-2 pl-3">C.I. Estudiante</th>
                        <th className="p-2">Apellidos y Nombres</th>
                        <th className="p-2">Curso</th>
                        <th className="p-2">Mora (Deuda)</th>
                        <th className="p-2">Tutor Legal</th>
                        <th className="p-2">Teléfono</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-150 text-slate-600 font-medium">
                      {mappedStudents.map((st, idx) => (
                        <tr key={idx} className="hover:bg-slate-50 transition">
                          <td className="p-2 pl-3 font-mono text-slate-500">{st.ci}</td>
                          <td className="p-2 font-bold text-slate-800 uppercase">{st.fullName}</td>
                          <td className="p-2">
                            <span className="bg-blue-50 text-blue-700 px-1.5 py-0.5 rounded font-mono text-[9px] font-bold">
                              {st.grade}
                            </span>
                          </td>
                          <td className="p-2">
                            {st.hasDebts ? (
                              <span className="text-red-700 bg-red-50 px-1 py-0.2 rounded font-bold text-[9.5px]">Bs. {st.totalDebtAmount} (CON MORA)</span>
                            ) : (
                              <span className="text-emerald-700 bg-emerald-50 px-1 py-0.2 rounded font-bold text-[9.5px]">Al Día</span>
                            )}
                          </td>
                          <td className="p-2 uppercase text-slate-700 text-[10px] truncate max-w-[120px]">{st.guardianName}</td>
                          <td className="p-2 font-mono text-slate-500">{st.guardianPhone}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

            </div>
          )}

        </div>

        {/* Modal Footer actions */}
        <div className="bg-slate-50 border-t border-slate-200 px-6 py-4 flex items-center justify-between shadow-inner">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 border border-slate-300 rounded-xl text-xs font-bold text-slate-700 hover:bg-slate-100 transition active:scale-[0.98] cursor-pointer bg-white"
          >
            Cancelar
          </button>
          
          <button
            type="button"
            disabled={mappedStudents.length === 0}
            onClick={handleImportExecute}
            className={`px-5 py-2.5 rounded-xl text-xs font-extrabold text-white flex items-center space-x-1.5 transition-all shadow-md cursor-pointer ${
              mappedStudents.length === 0
                ? 'bg-slate-300 border-slate-300 text-slate-500 cursor-not-allowed shadow-none'
                : importMode === 'replace'
                  ? 'bg-red-600 hover:bg-red-700 shadow-red-500/10'
                  : 'bg-emerald-700 hover:bg-emerald-800 shadow-emerald-500/10'
            }`}
          >
            <CheckCircle className="w-4.5 h-4.5" />
            <span>Ejecutar Importación ({mappedStudents.length} Alumnos)</span>
          </button>
        </div>

      </div>
    </div>
  );
}
