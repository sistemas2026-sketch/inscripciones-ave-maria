import React, { useState, useEffect } from 'react';
import { Student, Settings } from '../types';
import { FileText, Download, CheckCircle2, AlertCircle, Info, Landmark } from 'lucide-react';
import { jsPDF } from 'jspdf';

interface ContractViewerProps {
  student: Partial<Student>;
  settings: Settings;
  onSign: (signedByName: string, signatureDataUrl: string) => void;
  isViewOnly?: boolean;
  savedSignature?: string;
}

export default function ContractViewer({
  student,
  settings,
  onSign,
  isViewOnly = false,
  savedSignature
}: ContractViewerProps) {
  // Local state for additional fields like Address (Domicilio) required in the contract
  const [address, setAddress] = useState(student.newStudentData?.address || '');
  const [typedName, setTypedName] = useState(student.guardianName || '');
  const [typedCI, setTypedCI] = useState(student.guardianCI || '');
  const [typedPhone, setTypedPhone] = useState(student.guardianPhone || '');
  
  const [isChecked, setIsChecked] = useState(!!isViewOnly || !!savedSignature);
  const [hasDownloaded, setHasDownloaded] = useState(!!isViewOnly || !!savedSignature);
  const [error, setError] = useState('');

  // Sync state if student changes
  useEffect(() => {
    if (student.guardianName && !typedName) setTypedName(student.guardianName);
    if (student.guardianCI && !typedCI) setTypedCI(student.guardianCI);
    if (student.guardianPhone && !typedPhone) setTypedPhone(student.guardianPhone);
    if (student.newStudentData?.address && !address) setAddress(student.newStudentData.address);
  }, [student]);

  const handleDownloadPDF = () => {
    if (!typedName.trim()) {
      setError('Por favor, ingrese el nombre completo del Tutor Legal para el contrato.');
      return;
    }
    if (!typedCI.trim()) {
      setError('Por favor, ingrese el número de C.I. del Tutor Legal.');
      return;
    }
    if (!address.trim()) {
      setError('Por favor, ingrese el Domicilio actual del Tutor Legal.');
      return;
    }

    try {
      setError('');
      const doc = new jsPDF({
        orientation: 'portrait',
        unit: 'mm',
        format: 'a4'
      });

      let y = 20;

      const addHeader = () => {
        // Aesthetic Top Header Bar
        doc.setDrawColor(23, 103, 153);
        doc.setLineWidth(1);
        doc.line(20, y, 190, y);
        y += 6;
        
        doc.setFont('helvetica', 'bold');
        doc.setFontSize(8);
        doc.setTextColor(35, 82, 111);
        doc.text("UNIDAD EDUCATIVA AVE MARÍA", 20, y);
        doc.text(`GESTIÓN ESCOLAR ${settings.currentYear}`, 190, y, { align: 'right' });
        y += 8;
      };

      const addParagraph = (text: string, size = 10, style: 'normal' | 'bold' | 'italic' = 'normal', spaceAfter = 5) => {
        doc.setFontSize(size);
        doc.setFont('helvetica', style);
        doc.setTextColor(33, 55, 68); // Brand dark charcoal
        
        const lines = doc.splitTextToSize(text, 170);
        lines.forEach((line: string) => {
          if (y > 270) {
            doc.addPage();
            y = 15;
            addHeader();
          }
          doc.text(line, 20, y);
          y += (size * 0.35) + 3.2; // Line height spacing
        });
        y += spaceAfter;
      };

      const drawBox = (title: string, fields: { label: string; value: string }[]) => {
        if (y > 220) {
          doc.addPage();
          y = 15;
          addHeader();
        }

        // Box border & inner fill
        doc.setDrawColor(166, 221, 255);
        doc.setFillColor(245, 250, 255);
        doc.rect(20, y, 170, fields.length * 8 + 10, 'FD');
        
        let boxY = y + 7;
        doc.setFont('helvetica', 'bold');
        doc.setFontSize(9);
        doc.setTextColor(23, 103, 153);
        doc.text(title, 24, boxY);
        boxY += 6;
        
        fields.forEach(f => {
          doc.setFont('helvetica', 'normal');
          doc.setFontSize(8.5);
          doc.setTextColor(33, 55, 68);
          // Label
          doc.text(`${f.label}:`, 24, boxY);
          // Value
          doc.setFont('helvetica', 'bold');
          doc.setTextColor(21, 55, 68);
          doc.text(f.value || 'N/A', 80, boxY);
          boxY += 8;
        });
        
        y += fields.length * 8 + 16;
      };

      // INIT DESIGN
      addHeader();

      // Title
      doc.setFontSize(14);
      doc.setFont('helvetica', 'bold');
      doc.setTextColor(23, 103, 153);
      doc.text("CONTRATO DE SERVICIO EDUCATIVO", 105, y, { align: 'center' });
      y += 6;
      doc.text(`GESTIÓN ${settings.currentYear}`, 105, y, { align: 'center' });
      y += 10;

      // Introductory paragraph
      const introText = "Conste por el presente documento privado un Contrato de Servicio Educativo, que con el solo reconocimiento de firmas surtirá efectos de documento público, conforme a los arts. 454 y 519 del Código Civil (CC), demás normas aplicables y bajo las siguientes cláusulas:";
      addParagraph(introText, 9.5, 'normal', 6);

      // PARTES CONSTITUYENTES TITLE
      addParagraph("CONSTITUCIÓN DE LAS PARTES", 11, 'bold', 4);

      // UE Text
      const ueText = "I. LA UNIDAD EDUCATIVA.\nRepresentada legalmente por el Lic. ISAIAS SÁNCHEZ YUJRA, con C.I. N.º 4823481 Q.R., en su calidad de Apoderado designado mediante Testimonio de Poder N.º 3/2024, actuando en nombre de la FUNDACIÓN AVE MARÍA – FUNDACIÓN MANOS ABIERTAS VIRGEN DE LA NATIVIDAD, con NIT N.º 142391024, con domicilio en la calle René Dorado N.º 387, zona Anexo 16 de Julio, ciudad de El Alto, a quien en adelante se denominará “LA UNIDAD EDUCATIVA”.";
      addParagraph(ueText, 9.5, 'normal', 5);

      // Tutor Text
      const tutorText = "II. LOS PADRES.\nEl padre, madre, tutor o apoderado legal del estudiante, cuyos datos se consignan a continuación, a quienes en adelante se denominará “LOS PADRES”:";
      addParagraph(tutorText, 9.5, 'normal', 5);

      // BOX 1: DATA OF GUARDIAN
      drawBox("REGISTRO DE LOS PADRES / TUTOR LEGAL", [
        { label: "Nombre del padre, madre, tutor o apoderado", value: typedName.toUpperCase() },
        { label: "Domicilio (Ciudad, Zona, Calle/Avenida y Nro)", value: address },
        { label: "Teléfono de Contacto", value: typedPhone }
      ]);

      // BOX 2: DATA OF STUDENT
      drawBox("DATOS DEL O LA ESTUDIANTE", [
        { label: "Nombre del o la estudiante", value: (student.fullName || 'N/A').toUpperCase() },
        { label: "Documento de Identidad (C.I.)", value: student.ci || 'N/A' },
        { label: "Curso / Grado correspondiente", value: student.grade || 'N/A' }
      ]);

      // CLAUSULA PRIMERA
      addParagraph("CLÁUSULA PRIMERA. OBJETO", 10.5, 'bold', 3);
      const c1Text = `El presente contrato tiene por objeto regular la prestación del servicio educativo a favor del estudiante identificado, a cambio del pago de las pensiones escolares y el cumplimiento de las obligaciones establecidas, conforme a la Ley N.º 070, la Resolución Ministerial N.º 01/${settings.currentYear}, el Proyecto Educativo Institucional (PEI), el Reglamento Interno y las normas de convivencia escolar, documentos que LOS PADRES declaran conocer y aceptar, formando parte integrante del presente contrato.`;
      addParagraph(c1Text, 9.5, 'normal', 6);

      // CLAUSULA SEGUNDA
      addParagraph("CLÁUSULA SEGUNDA. OBLIGACIONES ESENCIALES", 10.5, 'bold', 3);
      const c2a = "a) De LOS PADRES:\nCumplir oportunamente con el pago de las pensiones escolares y demás obligaciones económicas asumidas, comprometerse en el cumplimiento de las normas internas por parte del estudiante y asumir como PADRES responsabilidad respectiva por posibles daños ocasionados a la infraestructura y/o mobiliario educativo, colaborando así activamente en su proceso formativo.";
      addParagraph(c2a, 9.5, 'normal', 4);
      const c2b = "b) De LA UNIDAD EDUCATIVA:\nBrindar un servicio educativo de calidad, conforme al PEI y a la normativa vigente, garantizando las condiciones materiales, técnicas, pedagógicas y de talento humano necesarias para el desarrollo integral del estudiante.";
      addParagraph(c2b, 9.5, 'normal', 6);

      // CLAUSULA TERCERA
      addParagraph("CLÁUSULA TERCERA. PENSIONES Y PAGOS", 10.5, 'bold', 3);
      const c3_1 = `I. Monto y periodicidad.\nLa pensión escolar mensual para la Gestión ${settings.currentYear} es de Bs. 780,00 (Setecientos ochenta 00/100 bolivianos), pagadera en diez (10) cuotas correspondientes a los meses de febrero a noviembre, totalizando Bs. 7.800,00 anuales.`;
      addParagraph(c3_1, 9.5, 'normal', 4);
      const c3_2 = "II. Forma y plazo de pago.\nEl pago deberá realizarse hasta el día 10 de cada mes. El incumplimiento faculta a LA UNIDAD EDUCATIVA a exigir el pago por las vías legales correspondientes.";
      addParagraph(c3_2, 9.5, 'normal', 4);
      const c3_3 = `III. Incremento o ajuste de pensiones.\nNo se aplicará incremento alguno a las pensiones escolares, salvo autorización expresa conforme al art. 76.I de la Resolución Ministerial N.º 01/${settings.currentYear}, en la que se prevé que, en el mes de abril, una comisión mixta, conformada por el Ministerio de Educación, Ministerio de Economía y Finanzas Públicas y ANDECOP, analizará la posibilidad del incremento, considerando la situación económica del país y la política salarial adoptada hasta entonces.`;
      addParagraph(c3_3, 9.5, 'normal', 4);
      const c3_4 = "IV. Responsabilidad solidaria.\nLOS PADRES asumen responsabilidad solidaria por las obligaciones económicas emergentes del presente contrato.";
      addParagraph(c3_4, 9.5, 'normal', 6);

      // CLAUSULA CUARTA
      addParagraph("CLÁUSULA CUARTA. INCUMPLIMIENTO, GARANTÍAS, MORA, PROCESO JUDICIAL Y DOMICILIO ESPECIAL", 10.5, 'bold', 3);
      const c4_1 = "I. El incumplimiento de las obligaciones pecuniarias faculta a la UNIDAD EDUCATIVA a ejercer las acciones legales correspondientes. Los PADRES se constituyen en deudores y garantizan el pago de pensiones y demás obligaciones del contrato con todos sus bienes presentes y futuros, conforme al art. 1335 del CC, autorizando además la verificación y reporte de información crediticia a los Burós legalmente establecidos.";
      addParagraph(c4_1, 9.5, 'normal', 4);
      const c4_2 = "II. La falta o demora en el pago de cualquier cuota generará mora automática, sin necesidad de intimación previa, conforme al art. 341 inc. 1) del CC, haciendo la deuda vencida, líquida y exigible. A tal efecto, los PADRES constituyen como domicilio especial el señalado en la Cláusula Primera, válido para toda notificación judicial o extrajudicial, conforme al art. 29.II del CC.";
      addParagraph(c4_2, 9.5, 'normal', 4);
      const c4_3 = `III. La tolerancia en el cobro no implicará prórroga ni renuncia de derechos. Los PADRES que adeuden pensiones de las Gestiones anteriores reconocen la misma conforme al Certificado o Planilla de Adeudos emitido por la UNIDAD EDUCATIVA, que forma parte del presente contrato.`;
      addParagraph(c4_3, 9.5, 'normal', 4);
      const c4_4 = "IV. Los PADRES consienten que las obligaciones pendientes sean exigidas en un solo proceso judicial, que acumule en una sola demanda todas las peticiones de cumplimiento o pago que pudiera tener la UNIDAD EDUCATIVA respecto a los otros PADRES.";
      addParagraph(c4_4, 9.5, 'normal', 6);

      // CLAUSULA QUINTA Y SEXTA
      addParagraph("CLÁUSULA QUINTA. DOCUMENTACIÓN OBLIGATORIA", 10.5, 'bold', 3);
      const c5Text = "LOS PADRES deberán presentar la documentación completa requerida para la inscripción. La falta de entrega total de dicha documentación será causal de resolución del contrato, sin derecho a reclamo ni devolución de pagos efectuados.";
      addParagraph(c5Text, 9.5, 'normal', 6);

      addParagraph("CLÁUSULA SEXTA. VIGENCIA, RENOVACIÓN E INSCRIPCIÓN", 10.5, 'bold', 3);
      const c6_1 = `I. El presente contrato tiene vigencia exclusiva para la Gestión Escolar ${settings.currentYear} y no se renueva tácitamente.`;
      addParagraph(c6_1, 9.5, 'normal', 4);
      const c6_2 = `II. Para la inscripción en la Gestión ${settings.currentYear}, LOS PADRES deberán tener regularizadas sus obligaciones de gestiones anteriores.`;
      addParagraph(c6_2, 9.5, 'normal', 4);
      const c6_3 = `III. El adeudo de pensiones al cierre de la Gestión ${settings.currentYear} impedirá la inscripción automática para la Gestión subsiguiente, obligando a LOS PADRES a realizar los trámites de traslado correspondientes.`;
      addParagraph(c6_3, 9.5, 'normal', 6);

      // SIGNATURE STATEMENT
      const endText = `En señal de conformidad, las partes firman el presente contrato en la ciudad de La Paz, a los veinte (20) días del mes de enero de ${settings.currentYear}.`;
      addParagraph(endText, 9.5, 'italic', 12);

      // SIGNATURE LINES
      if (y > 230) {
        doc.addPage();
        y = 15;
        addHeader();
      }

      y += 15;
      doc.setDrawColor(150, 150, 150);
      doc.setLineWidth(0.5);

      // Left column line
      doc.line(20, y, 90, y);
      // Right column line
      doc.line(120, y, 190, y);

      y += 5;
      doc.setFontSize(8);
      doc.setTextColor(33, 55, 68);

      // Left details
      doc.setFont('helvetica', 'normal');
      doc.text("Firma del Padre, Madre o Tutor", 20, y);
      doc.setFont('helvetica', 'bold');
      doc.text(typedName.toUpperCase(), 20, y + 4.5);
      doc.setFont('helvetica', 'normal');
      doc.text(`C.I.: ${typedCI}`, 20, y + 9);

      // Right details
      doc.setFont('helvetica', 'bold');
      doc.text("LIC. ISAIAS SANCHEZ YUJRA", 120, y);
      doc.setFont('helvetica', 'normal');
      doc.text("C.I. 4823481 QR", 120, y + 4.5);
      doc.text("APODERADO", 120, y + 9);
      doc.text("AVE MARÍA F.M.A.V.N.", 120, y + 13.5);

      // SAVE FILE
      const studentSlug = (student.fullName || 'estudiante').toLowerCase().replace(/\s+/g, '_');
      doc.save(`Contrato_Servicio_Educativo_${settings.currentYear}_${studentSlug}.pdf`);

      setHasDownloaded(true);
      
      // Auto toggle consent check when user downloads the file
      setIsChecked(true);
      onSign(typedName, 'downloaded-pdf-contract');
    } catch (err: any) {
      console.error(err);
      setError('Ocurrió un error al generar el archivo PDF del contrato. Verifique sus datos.');
    }
  };

  const handleCheckboxToggle = (checked: boolean) => {
    setIsChecked(checked);
    if (checked && hasDownloaded) {
      onSign(typedName, 'downloaded-pdf-contract');
    } else if (checked && !hasDownloaded) {
      // Allow accepting and auto-unlocking, but reinforce downloading is recommended
      onSign(typedName, 'downloaded-pdf-contract');
    }
  };

  return (
    <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-sm max-w-4xl mx-auto my-6" id="educational-contract">
      {/* Contract Header info */}
      <div className="bg-slate-50 border-b border-slate-200 px-6 py-4 flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <FileText className="w-5 h-5 text-blue-700" />
          <h3 className="font-semibold text-slate-800">CONTRATO DE SERVICIOS EDUCATIVOS - GESTIÓN {settings.currentYear}</h3>
        </div>
        <span className="text-xs font-mono px-2.5 py-1 bg-[#a6ddff]/30 text-blue-800 rounded-full font-bold">PDF REQUERIDO</span>
      </div>

      {/* Contract Screen Information Alert */}
      <div className="bg-blue-50/50 border-b border-blue-100/80 p-4 shrink-0 text-slate-700 text-xs leading-normal flex items-start space-x-2.5">
        <Info className="w-4.5 h-4.5 text-blue-600 shrink-0 mt-0.5" />
        <div>
          <p className="font-semibold text-slate-800">Instrucciones de registro de contrato:</p>
          <ul className="list-disc pl-4 mt-1 space-y-1 text-slate-600">
            <li>Complete sus datos de tutor legal y la dirección de <strong>Domicilio actual</strong> requerida por la Unidad Educativa.</li>
            <li>No se requiere dibujar una firma a mano en pantalla.</li>
            <li><strong>Descargue el contrato formal en formato PDF</strong> de manera obligatoria y guárdelo para sus registros personales.</li>
          </ul>
        </div>
      </div>

      {/* Interactive Form for Tutor Details filling */}
      <div className="p-6 bg-slate-50/30 border-b border-slate-200">
        <h4 className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-4">Información del Tutor para el Documento</h4>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <label className="block text-[11px] font-bold text-slate-600 uppercase mb-1.5">Nombre del Apoderado Legal</label>
            <input
              type="text"
              disabled={isViewOnly}
              value={typedName}
              onChange={(e) => {
                setTypedName(e.target.value);
                if (isChecked) onSign(e.target.value, 'downloaded-pdf-contract');
              }}
              placeholder="Nombre y Apellidos"
              className="w-full text-xs px-3.5 py-2.5 bg-white border border-slate-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-blue-600 focus:border-blue-600 text-slate-800 font-semibold"
            />
          </div>
          <div>
            <label className="block text-[11px] font-bold text-slate-600 uppercase mb-1.5">C.I. del Apoderado Legal</label>
            <input
              type="text"
              disabled={isViewOnly}
              value={typedCI}
              onChange={(e) => setTypedCI(e.target.value)}
              placeholder="Número de C.I. y Exp."
              className="w-full text-xs px-3.5 py-2.5 bg-white border border-slate-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-blue-600 focus:border-blue-600 text-slate-800 font-semibold"
            />
          </div>
          <div>
            <label className="block text-[11px] font-bold text-slate-600 uppercase mb-1.5">Teléfono de Contacto</label>
            <input
              type="text"
              disabled={isViewOnly}
              value={typedPhone}
              onChange={(e) => setTypedPhone(e.target.value)}
              placeholder="Número de Teléfono/Celular"
              className="w-full text-xs px-3.5 py-2.5 bg-white border border-slate-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-blue-600 focus:border-blue-600 text-slate-800 font-semibold"
            />
          </div>
          <div className="md:col-span-3">
            <label className="block text-[11px] font-bold text-slate-600 uppercase mb-1.5">Domicilio del Tutor (Ciudad, Zona, Calle o Avenida y Número) <strong className="text-red-500">*</strong></label>
            <input
              type="text"
              disabled={isViewOnly}
              value={address}
              onChange={(e) => setAddress(e.target.value)}
              placeholder="Ej.: El Alto, Zona Anexo 16 de Julio, Calle René Dorado Nro. 387"
              className="w-full text-xs px-3.5 py-2.5 bg-white border border-slate-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-blue-600 focus:border-blue-600 text-slate-800 font-semibold"
            />
          </div>
        </div>
      </div>

      {/* Contract Document Body Previewer */}
      <div className="p-8 max-h-[300px] overflow-y-auto text-slate-700 text-xs leading-relaxed space-y-4 select-text custom-scrollbar bg-white">
        <div className="text-center font-extrabold text-slate-800 text-sm mb-4 uppercase">
          CONTRATO DE SERVICIO EDUCATIVO
          <br />
          GESTIÓN {settings.currentYear}
        </div>

        <p className="indent-4 text-justify">
          Conste por el presente documento privado un Contrato de Servicio Educativo, que con el solo reconocimiento de firmas surtirá efectos de documento público, conforme a los arts. 454 y 519 del Código Civil (CC), demás normas aplicables y bajo las siguientes cláusulas:
        </p>

        <p className="font-extrabold text-slate-800 mt-4 uppercase">CONSTITUCIÓN DE LAS PARTES</p>
        
        <p className="text-justify font-normal pl-2">
          <strong>I. LA UNIDAD EDUCATIVA.</strong>
          <br />
          Representada legalmente por el Lic. ISAIAS SÁNCHEZ YUJRA, con C.I. N.º 4823481 Q.R., en su calidad de Apoderado designado mediante Testimonio de Poder N.º 3/2024, actuando en nombre de la FUNDACIÓN AVE MARÍA – FUNDACIÓN MANOS ABIERTAS VIRGEN DE LA NATIVIDAD, con NIT N.º 142391024, con domicilio en la calle René Dorado N.º 387, zona Anexo 16 de Julio, ciudad de El Alto, a quien en adelante se denominará “LA UNIDAD EDUCATIVA”.
        </p>

        <p className="text-justify font-normal pl-2">
          <strong>II. LOS PADRES.</strong>
          <br />
          El padre, madre, tutor o apoderado legal del estudiante, cuyos datos se consignan a continuación, a quienes en adelante se denominará “LOS PADRES”:
        </p>

        {/* Parties Dynamic preview tables */}
        <div className="my-4 border border-slate-200 rounded-lg overflow-hidden text-xs">
          <div className="grid grid-cols-3 bg-slate-100 border-b border-slate-200 font-bold p-2 text-slate-700 text-[10.5px]">
            <div>Nombre del tutor</div>
            <div>Domicilio</div>
            <div>Teléfono</div>
          </div>
          <div className="grid grid-cols-3 p-2 text-slate-600 bg-white items-center">
            <div className="font-semibold break-all text-slate-800">{typedName || "[Por llenar]"}</div>
            <div className="break-all">{address || "[Por llenar]"}</div>
            <div>{typedPhone || "[Por llenar]"}</div>
          </div>

          <div className="grid grid-cols-2 bg-slate-100 border-t border-b border-slate-200 font-bold p-2 text-slate-700 text-[10.5px] mt-2">
            <div>Nombre del estudiante</div>
            <div>Curso</div>
          </div>
          <div className="grid grid-cols-2 p-2 text-slate-600 bg-white items-center">
            <div className="font-semibold text-slate-800 uppercase">{student.fullName || "[Por llenar]"}</div>
            <div>{student.grade || "[Por llenar]"}</div>
          </div>
        </div>

        <p className="text-justify">
          <strong>CLÁUSULA PRIMERA. OBJETO</strong>
          <br />
          El presente contrato tiene por objeto regular la prestación del servicio educativo a favor del estudiante identificado, a cambio del pago de las pensiones escolares y el cumplimiento de las obligaciones establecidas, conforme a la Ley N.º 070, la Resolución Ministerial N.º 01/{settings.currentYear}, el Proyecto Educativo Institucional (PEI), el Reglamento Interno y las normas de convivencia escolar, documentos que LOS PADRES declaran conocer y aceptar, formando parte integrante del presente contrato.
        </p>

        <p className="text-justify">
          <strong>CLÁUSULA SEGUNDA. OBLIGACIONES ESENCIALES</strong>
          <br />
          <strong>a) De LOS PADRES:</strong> Cumplir oportunamente con el pago de las pensiones escolares y demás obligaciones económicas asumidas, comprometerse en el cumplimiento de las normas internas por parte del estudiante y asumir como PADRES responsabilidad respectiva por posibles daños ocasionados a la infraestructura y/o mobiliario educativo, colaborando así activamente en su proceso formativo.
          <br />
          <strong>b) De LA UNIDAD EDUCATIVA:</strong> Brindar un servicio educativo de calidad, conforme al PEI y a la normativa vigente, garantizando las condiciones materiales, técnicas, pedagógicas y de talento humano necesarias para el desarrollo integral del estudiante.
        </p>

        <p className="text-justify bg-slate-50 p-2.5 rounded-lg border border-slate-100 font-mono text-[10px]">
          <strong>CLÁUSULA TERCERA. PENSIONES Y PAGOS</strong>
          <br />
          <strong>I. Monto y periodicidad:</strong> La pensión escolar mensual para la Gestión {settings.currentYear} es de Bs. 780,00 (Setecientos ochenta 00/100 bolivianos), pagadera en diez (10) cuotas correspondientes a los meses de febrero a noviembre, totalizando Bs. 7.800,00 anuales.
          <br />
          <strong>II. Forma y plazo de pago:</strong> El pago deberá realizarse hasta el día 10 de cada mes. El incumplimiento faculta a LA UNIDAD EDUCATIVA a exigir el pago por las vías legales correspondientes.
          <br />
          <strong>III. Incremento o ajuste de pensiones:</strong> No se aplicará incremento alguno a las pensiones escolares, salvo autorización expresa conforme al art. 76.I de la Resolución Ministerial N.º 01/{settings.currentYear}, en la que se prevé que, en el mes de abril, una comisión mixta, conformada por el Ministerio de Educación, Ministerio de Economía y Finanzas Públicas y ANDECOP, analizará la posibilidad del incremento, considerando la situación económica del país y la política salarial adoptada hasta entonces.
          <br />
          <strong>IV. Responsabilidad solidaria:</strong> LOS PADRES asumen responsabilidad solidaria por las obligaciones económicas emergentes del presente contrato.
        </p>

        <p className="text-justify">
          <strong>CLÁUSULA CUARTA. INCUMPLIMIENTO, GARANTÍAS, MORA, PROCESO JUDICIAL Y DOMICILIO ESPECIAL</strong>
          <br />
          <strong>I.</strong> El incumplimiento de las obligaciones pecuniarias faculta a la UNIDAD EDUCATIVA a ejercer las acciones legales correspondientes. Los PADRES se constituyen en deudores y garantizan el pago de pensiones y demás obligaciones del contrato con todos sus bienes presentes y futuros, conforme al art. 1335 del CC, autorizando además la verificación y reporte de información crediticia a los Burós legalmente establecidos.
          <br />
          <strong>II.</strong> La falta o demora en el pago de cualquier cuota generará mora automática, sin necesidad de intimación previa, conforme al art. 341 inc. 1) del CC, haciendo la deuda vencida, líquida y exigible. A tal efecto, los PADRES constituyen como domicilio especial el señalado en la Cláusula Primera, válido para toda notificación judicial o extrajudicial, conforme al art. 29.II del CC.
          <br />
          <strong>III.</strong> La tolerancia en el cobro no implicará prórroga ni renuncia de derechos. Los PADRES que adeuden pensiones de las Gestiones 2025 y gestiones anteriores reconocen la misma conforme al Certificado o Planilla de Adeudos emitido por la UNIDAD EDUCATIVA, que forma parte del presente contrato.
          <br />
          <strong>IV.</strong> Los PADRES consienten que las obligaciones pendientes sean exigidas en un solo proceso judicial, que acumule en una sola demanda todas las peticiones de cumplimiento o pago que pudiera tener la UNIDAD EDUCATIVA respecto a los otros PADRES.
        </p>

        <p className="text-justify">
          <strong>CLÁUSULA QUINTA. DOCUMENTACIÓN OBLIGATORIA</strong>
          <br />
          LOS PADRES deberán presentar la documentación completa requerida para la inscripción. La falta de entrega total de dicha documentación será causal de resolución del contrato, sin derecho a reclamo ni devolución de pagos efectuados.
        </p>

        <p className="text-justify">
          <strong>CLÁUSULA SEXTA. VIGENCIA, RENOVACIÓN E INSCRIPCIÓN</strong>
          <br />
          <strong>I.</strong> El presente contrato tiene vigencia exclusiva para la Gestión Escolar {settings.currentYear} y no se renueva tácitamente.
          <br />
          <strong>II.</strong> Para la inscripción en la Gestión {settings.currentYear}, LOS PADRES deberán tener regularizadas sus obligaciones de gestiones anteriores.
          <br />
          <strong>III.</strong> El adeudo de pensiones al cierre de la Gestión {settings.currentYear} impedirá la inscripción automática para la Gestión {parseInt(settings.currentYear, 10) + 1}, obligando a LOS PADRES a realizar los trámites de traslado correspondientes.
        </p>

        <p className="text-right italic text-[11px] text-slate-500 mt-4">
          La Paz, {settings.currentYear}.
        </p>

        <div className="flex justify-between text-[10px] pt-8 border-t border-dashed border-slate-200">
          <div>
            <div className="w-48 border-b border-slate-300 h-10 mb-1"></div>
            <p className="font-bold uppercase text-slate-700">{typedName || "Tutor Legal"}</p>
            <p className="text-slate-500">C.I.: {typedCI || "Por Llenar"}</p>
          </div>
          <div className="text-right">
            <div className="w-48 border-b border-slate-300 h-10 mb-1 ml-auto"></div>
            <p className="font-bold text-slate-700">Lic. Isaias Sánchez Yujra</p>
            <p className="text-slate-500">C.I. 4823481 Q.R. / Apoderado</p>
            <p className="text-slate-400 text-[9px]">U.E. Ave María F.M.A.V.N.</p>
          </div>
        </div>
      </div>

      {/* Trigger & Confirmation Area */}
      <div className="bg-slate-50 border-t border-slate-200 p-6">
        {error && (
          <div className="mb-4 bg-red-50 border border-red-100 text-red-700 p-3.5 rounded-lg text-xs flex items-center space-x-2.5">
            <AlertCircle className="w-4 h-4 text-red-600 shrink-0" />
            <span className="font-semibold">{error}</span>
          </div>
        )}

        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-6">
          {/* Checkbox of Agreement */}
          <div className="flex-1">
            <label className="flex items-start space-x-3 text-slate-700 cursor-pointer select-none">
              <input
                type="checkbox"
                disabled={isViewOnly}
                checked={isChecked}
                onChange={(e) => handleCheckboxToggle(e.target.checked)}
                className="mt-0.5 w-4.5 h-4.5 rounded border-slate-300 text-blue-700 focus:ring-blue-600 focus:outline-none transition cursor-pointer"
              />
              <div className="text-xs">
                <p className="font-bold text-slate-800">Declaro mi conformidad absoluta con el contrato educativo</p>
                <p className="text-slate-500 mt-0.5">Certifico que los datos son fidedignos y me comprometo a cumplir con todas las cláusulas establecidas.</p>
              </div>
            </label>
          </div>

          {/* Action buttons */}
          <div className="flex items-center space-x-3 shrink-0">
            <button
              type="button"
              onClick={handleDownloadPDF}
              className="bg-blue-700 hover:bg-blue-800 text-white font-bold text-xs px-5 py-3 rounded-xl flex items-center space-x-2 transition-all shadow-md shadow-blue-500/10 cursor-pointer"
            >
              <Download className="w-4 h-4" />
              <span>Descargar Contrato (PDF)</span>
            </button>
            
            {hasDownloaded && (
              <div className="text-xs text-emerald-600 font-bold flex items-center space-x-1.5 bg-emerald-50 px-3.5 py-3 rounded-xl border border-emerald-100/50">
                <CheckCircle2 className="w-4.5 h-4.5 text-emerald-600 shrink-0" />
                <span>PDF Descargado</span>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
