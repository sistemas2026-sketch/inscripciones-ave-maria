import React, { useState, useEffect } from 'react';
import { Student, Settings } from './types';
import { 
  getStoredStudents, saveStoredStudents, getStoredSettings, saveStoredSettings 
} from './data';
import StudentLogin from './components/StudentLogin';
import StudentRegisterForm from './components/StudentRegisterForm';
import AdminPanel from './components/AdminPanel';
import SchoolLogo from './components/SchoolLogo';
import { School, HelpCircle, ShieldAlert, CheckCircle, Landmark, GraduationCap, X } from 'lucide-react';

export default function App() {
  const [students, setStudents] = useState<Student[]>([]);
  const [settings, setSettings] = useState<Settings>({
    schoolName: "Ave María - Fundación Manos Abiertas Virgen de la Natividad",
    currentYear: "2026",
    monthlyTuition: 450,
    matriculaAmount: 380,
    adminPasscode: "admin123",
    bankInfo: {
      bankName: "Banco Mercantil Santa Cruz (BMSC)",
      accountNumber: "1000293847",
      accountType: "Cuenta Corriente",
      accountHolder: "Fundación Manos Abiertas - Ave María",
      nitOrCI: "1028345025"
    }
  });

  const [isAdmin, setIsAdmin] = useState(false);
  const [showPasscodePrompt, setShowPasscodePrompt] = useState(false);
  const [passcodeInput, setPasscodeInput] = useState('');
  const [passcodeError, setPasscodeError] = useState('');
  const [showPasscode, setShowPasscode] = useState(false);
  const [currentStudent, setCurrentStudent] = useState<Student | null>(null);
  const [notification, setNotification] = useState<string | null>(null);

  // Initialize and load persistent data
  useEffect(() => {
    const loadedStudents = getStoredStudents();
    const loadedSettings = getStoredSettings();
    setStudents(loadedStudents);
    if (loadedSettings && !loadedSettings.adminPasscode) {
      loadedSettings.adminPasscode = "admin123";
    }
    setSettings(loadedSettings);
  }, []);

  // Update students database
  const handleUpdateStudents = (updatedStudents: Student[]) => {
    setStudents(updatedStudents);
    saveStoredStudents(updatedStudents);
  };

  // Update Settings
  const handleUpdateSettings = (updatedSettings: Settings) => {
    setSettings(updatedSettings);
    saveStoredSettings(updatedSettings);
  };

  // Process successful ratification (returning student completes form)
  const handleRegistrationSuccess = (updatedStudent: Student) => {
    const updatedList = students.map(s => s.ci === updatedStudent.ci ? updatedStudent : s);
    handleUpdateStudents(updatedList);
    setCurrentStudent(null);
    triggerNotification(`¡Inscripción ratificada de manera exitosa para ${updatedStudent.fullName}!`);
  };

  const triggerNotification = (msg: string) => {
    setNotification(msg);
    setTimeout(() => {
      setNotification(null);
    }, 6000);
  };

  return (
    <div className="bg-slate-50 min-h-screen flex flex-col font-sans select-none antialiased">
      
      {/* Dynamic Global Top notification toast */}
      {notification && (
        <div className="fixed top-4 right-4 z-50 bg-emerald-700 text-white font-bold text-xs p-4 rounded-xl shadow-2xl border border-emerald-600 flex items-center space-x-2 animate-bounce max-w-sm">
          <CheckCircle className="w-5 h-5 shrink-0" />
          <span>{notification}</span>
        </div>
      )}

      {/* Modal de Validación de Contraseña de Administrador */}
      {showPasscodePrompt && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl border border-slate-100 max-w-sm w-full overflow-hidden animate-[scale_0.2s_ease-out]">
            {/* Header */}
            <div className="bg-gradient-to-br from-blue-800 to-slate-900 p-5 text-white flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <ShieldAlert className="w-5 h-5 text-amber-300" />
                <h3 className="font-bold text-sm tracking-tight text-white">Acceso de Administrador</h3>
              </div>
              <button 
                onClick={() => {
                  setShowPasscodePrompt(false);
                  setPasscodeInput('');
                  setPasscodeError('');
                }}
                className="text-white/60 hover:text-white hover:bg-white/10 p-1.5 rounded-lg transition shrink-0 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Prompt Body */}
            <form onSubmit={(e) => {
              e.preventDefault();
              const entered = passcodeInput.trim();
              const expected = (settings.adminPasscode || "admin123").trim();
              
              // Permit both admin123 and administrador123 as defaults
              const isDefaultMatch = (expected === "admin123" || expected === "administrador123") && 
                                     (entered === "admin123" || entered === "administrador123");
              
              const isExactMatch = entered === expected;

              if (isExactMatch || isDefaultMatch) {
                setIsAdmin(true);
                setShowPasscodePrompt(false);
                setPasscodeInput('');
                setPasscodeError('');
              } else {
                setPasscodeError('Código de acceso incorrecto. Verifique e intente de nuevo.');
              }
            }} className="p-6 space-y-4">
              <p className="text-xs text-slate-500 leading-relaxed">
                Este módulo es estrictamente para la administración y control de la <strong>Unidad Educativa Ave María</strong>.
              </p>

              <div>
                <label className="block text-[10.5px] font-bold text-slate-500 uppercase tracking-wider mb-1.5">
                  Código de Seguridad
                </label>
                <div className="relative">
                  <input
                    type={showPasscode ? "text" : "password"}
                    value={passcodeInput}
                    onChange={(e) => {
                      setPasscodeInput(e.target.value);
                      if (passcodeError) setPasscodeError('');
                    }}
                    placeholder="Ingrese código de acceso"
                    autoFocus
                    className="w-full text-xs px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-blue-600 focus:border-blue-600 font-mono tracking-widest text-slate-800"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPasscode(!showPasscode)}
                    className="absolute right-2.5 top-2.5 text-slate-400 hover:text-slate-600 text-[10px] font-bold uppercase tracking-wider px-1 py-0.5 rounded transition cursor-pointer"
                  >
                    {showPasscode ? "Ocultar" : "Ver"}
                  </button>
                </div>
                {passcodeError && (
                  <p className="text-[10.5px] text-red-600 font-semibold mt-1.5 flex items-center space-x-1">
                    <span>⚠️ {passcodeError}</span>
                  </p>
                )}
                <p className="text-[9.5px] text-slate-400 mt-2 italic">
                  * Código por defecto de instalación: <strong className="font-mono">admin123</strong>
                </p>
              </div>

              <div className="flex space-x-2.5 pt-2">
                <button
                  type="button"
                  onClick={() => {
                     setShowPasscodePrompt(false);
                     setPasscodeInput('');
                     setPasscodeError('');
                  }}
                  className="flex-1 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold py-2 rounded-lg transition border border-slate-200 cursor-pointer"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="flex-1 bg-blue-700 hover:bg-blue-800 text-white text-xs font-bold py-2 rounded-lg transition shadow-md shadow-blue-500/10 cursor-pointer"
                >
                  Confirmar
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Render Admin Panel as full screen portal if active */}
      {isAdmin ? (
        <AdminPanel
          students={students}
          settings={settings}
          onUpdateStudents={handleUpdateStudents}
          onUpdateSettings={handleUpdateSettings}
          onClose={() => setIsAdmin(false)}
        />
      ) : (
        /* STANDARD REGISTER PORTAL CLIENT FACING VIEW */
        <div className="flex-1 flex flex-col justify-between">
          
          {/* Header of School Portal */}
          <header className="bg-white border-b border-slate-200/80 py-3 px-6 md:px-12 flex justify-between items-center shadow-sm shrink-0">
            <div className="flex items-center space-x-3.5">
              <div className="w-14 h-14 bg-slate-50 rounded-xl flex items-center justify-center p-1 border border-slate-100/80 shadow-sm shrink-0">
                <SchoolLogo className="w-12 h-12" variant="appbar" />
              </div>
              <div className="text-left">
                <h1 className="font-extrabold text-slate-800 text-sm tracking-tight leading-none max-w-xs md:max-w-md">{settings.schoolName}</h1>
                <span className="text-[10px] text-slate-400 font-bold block mt-1 uppercase tracking-wider">Trámites y Matrículas en Línea</span>
              </div>
            </div>

            <div className="flex items-center space-x-4">
              <span className="hidden md:inline-flex items-center space-x-1.5 px-3 py-1 bg-amber-50 text-amber-800 border border-amber-200 rounded-full text-[10.5px] font-bold">
                <GraduationCap className="w-4 h-4 text-amber-600" />
                <span>Gestión Escolar {settings.currentYear}</span>
              </span>
              
              <button
                onClick={() => setShowPasscodePrompt(true)}
                className="text-xs bg-slate-900 hover:bg-slate-800 hover:text-white text-white/90 font-mono font-bold px-3 py-1.5 rounded-lg border border-slate-700 hover:border-slate-600 transition cursor-pointer"
              >
                ADMINISTRADOR
              </button>
            </div>
          </header>

          {/* Main Content Area */}
          <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8 md:py-12 flex items-center justify-center">
            
            {/* View dispatch routing state */}
            {currentStudent ? (
              /* ACTIVE RETURNING STUDENT FORM SIGNING */
              <StudentRegisterForm
                student={currentStudent}
                settings={settings}
                onSuccess={handleRegistrationSuccess}
                onCancel={() => setCurrentStudent(null)}
              />
            ) : (
              /* LOGIN/LANDING CARD */
              <StudentLogin
                students={students}
                onLoginSuccess={(student) => setCurrentStudent(student)}
                onToggleAdmin={() => setShowPasscodePrompt(true)}
              />
            )}

          </main>

          {/* Footer branding */}
          <footer className="bg-white border-t border-slate-100 py-6 px-6 text-center text-xs text-slate-400 shrink-0">
            <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center gap-2">
              <p>© {settings.currentYear} {settings.schoolName}. Todos los derechos reservados. Dirección de Admisiones y Control Financiero.</p>
              <div className="flex space-x-4 text-[11px] font-medium text-slate-400">
                <span className="hover:text-blue-700 transition">Términos del Contrato</span>
                <span>•</span>
                <span className="hover:text-blue-700 transition">Caja y Cobranzas</span>
                <span>•</span>
                <span className="hover:text-blue-700 transition">Soporte Técnico Ave María</span>
              </div>
            </div>
          </footer>
        </div>
      )}

    </div>
  );
}
